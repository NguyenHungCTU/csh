from __future__ import print_function

import os
import sys
import unittest


MODULE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, MODULE_DIR)
import analyze_module_connections_v2 as analyzer


class AnalyzerV2Test(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        report = os.path.join(MODULE_DIR, "sample", "sample_innovus_full_timing.rpt")
        cls.paths = analyzer.parse_report(report, 2)
        for index, path in enumerate(cls.paths, 1):
            path.path_id = index

    def test_full_report_and_statistical_values(self):
        self.assertEqual(len(self.paths), 2)
        path = self.paths[0]
        self.assertEqual(path.check_type, "recovery")
        self.assertEqual(path.path_group, "reg2reg")
        self.assertEqual(path.analysis_view, "VIEW_FUNC_SETUP_SSG0P81VM40C_TCMAX")
        self.assertAlmostEqual(path.metric("required"), -3.658)
        self.assertAlmostEqual(path.metric_mean("required"), -3.641)
        self.assertAlmostEqual(path.metric_sigma("required"), 0.006)
        self.assertAlmostEqual(path.metric("arrival"), -1.944)
        self.assertAlmostEqual(path.slack, -1.703)
        self.assertAlmostEqual(path.metric_mean("slack"), -1.677)
        self.assertAlmostEqual(path.metric_sigma("slack"), 0.009)

    def test_timing_and_other_end_sections_are_separate(self):
        path = self.paths[0]
        timing = [point for point in path.points if point.section == "timing_path"]
        other = [point for point in path.points if point.section == "other_end_path"]
        self.assertEqual(len(timing), 10)
        self.assertEqual(len(other), 10)
        self.assertEqual(sum(point.segment == "begin_clock_path" for point in timing), 6)
        self.assertEqual(sum(point.segment == "beginpoint" for point in timing), 1)
        self.assertEqual(sum(point.segment == "checked_signal_path" for point in timing), 2)
        self.assertEqual(sum(point.segment == "endpoint" for point in timing), 1)
        self.assertTrue(all(point.segment == "end_clock_path" for point in other))

    def test_module_segments_follow_checked_signal_only(self):
        segments = analyzer.build_segments(self.paths[1], "group_impl")
        self.assertEqual([row["module"] for row in segments], [
            "/cpu_module/cpu_sub_module/cpuAPB",
            "/sysctrl/module_a/datain/check",
        ])
        self.assertAlmostEqual(segments[0]["total_delay"], 1.130)
        self.assertAlmostEqual(segments[1]["total_delay"], 1.395)

    def test_boundary_aggregation(self):
        rows = analyzer.boundary_rows(self.paths, "group_impl")
        setup = [row for row in rows if row["check_type"] == "setup"][0]
        self.assertEqual(setup["source_module"], "/cpu_module/cpu_sub_module/cpuAPB")
        self.assertEqual(setup["destination_module"], "/sysctrl/module_a/datain/check")
        self.assertEqual(setup["path_count"], 1)
        self.assertEqual(setup["violation_count"], 1)
        self.assertEqual(setup["worst_slack"], "-0.145000")

    def test_dashboard_payload_is_summary_only(self):
        payload = analyzer.dashboard_payload(self.paths)
        self.assertEqual(len(payload["paths"]), 2)
        self.assertNotIn("details", payload)
        self.assertIn("route", payload["paths"][0])

    def test_detail_payload_contains_timing_points(self):
        payload = analyzer.detail_payload(self.paths)
        self.assertIn("details", payload)
        self.assertEqual(len(payload["details"]["1"]), len(self.paths[0].points))
        self.assertIn("segment", payload["details"]["1"][0])

    def test_collection_csv_input(self):
        export_dir = os.path.join(MODULE_DIR, "sample", "collection_export")
        paths = analyzer.parse_collection_export(export_dir, 2)
        for index, path in enumerate(paths, 1):
            path.path_id = index
        self.assertEqual(len(paths), 2)
        self.assertEqual(paths[0].input_source, "innovus_collection")
        self.assertEqual(paths[0].check_type, "recovery")
        self.assertAlmostEqual(paths[0].slack, -1.703)
        self.assertEqual(paths[1].launch_clock, "CPU_CLK")
        self.assertEqual(
            [row["module"] for row in analyzer.build_segments(paths[1], "strict")],
            ["/cpu_module/cpu_sub_module/cpuAPB", "/sysctrl/module_a/datain/check"],
        )

    def test_dashboards_are_separated_and_link_to_detail(self):
        template = os.path.join(MODULE_DIR, "dashboard_template_v2.html")
        with open(template, "r") as stream:
            content = stream.read()
        self.assertNotIn("<h2>Module matrix", content)
        self.assertIn("module_matrix_dashboard.html", content)
        self.assertIn("timing_path_detail.html#path=", content)
        matrix_template = os.path.join(MODULE_DIR, "matrix_template_v2.html")
        with open(matrix_template, "r") as stream:
            matrix_content = stream.read()
        self.assertIn("Module matrix", matrix_content)
        self.assertIn("Quick timing review", matrix_content)
        self.assertIn("timing_path_detail.html#path=", matrix_content)
        self.assertNotIn("Implementation cells", content)
        self.assertNotIn("Physical path", content)
        self.assertNotIn("Path segments", content)

    def test_header_only_path_keeps_endpoint_connection(self):
        path = analyzer.TimingPath("header_only.rpt", 1, "VIOLATED Setup Check")
        path.path_id = 99
        path.beginpoint = "cpu/core/reg1/Q"
        path.endpoint = "sysctrl/check/reg2/D"
        path.source_tokens = analyzer.hierarchy_tokens(path.beginpoint, 2)
        path.destination_tokens = analyzer.hierarchy_tokens(path.endpoint, 2)
        path.metrics["slack"] = (-0.100, None, None)
        segments = analyzer.build_segments(path, "group_impl")
        self.assertEqual([row["module"] for row in segments], ["/cpu/core", "/sysctrl/check"])


if __name__ == "__main__":
    unittest.main()
