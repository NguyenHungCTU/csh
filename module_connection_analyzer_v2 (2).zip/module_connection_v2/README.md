# Innovus Module Connection Analyzer V2

V2 analyzes the actual hierarchy crossed by checked-signal timing points and
creates a lightweight module-flow and module-matrix dashboard.

The recommended input is produced directly from Innovus timing collections.
This avoids dependence on `report_timing_format`, column width, statistical
report layout, or report-table wrapping.

## Requirements

- Innovus with collection-based `report_timing` and `get_property` support.
- Python 2.7 or Python 3.x.
- No third-party Python packages.
- A modern browser for the generated dashboard.

## Recommended workflow

### 1. Export canonical CSV files inside Innovus

```tcl
source innovus_export_module_paths.tcl

user_module_analyze "" "" "" 1000 module_connection_export late 1
```

Arguments:

```text
user_module_analyze from to path_group max_paths output_dir type_check violations_only
```

Example for setup/recovery paths:

```tcl
user_module_analyze "" "" reg2reg 1000 setup_export late 1
```

Example for hold/removal paths:

```tcl
user_module_analyze "" "" reg2reg 1000 hold_export early 1
```

Example with endpoints:

```tcl
user_module_analyze \
    u_cpu/u_reg1/Q \
    u_sys/u_reg2/D \
    reg2reg \
    100 \
    selected_export \
    late \
    0
```

The exporter creates:

```text
module_connection_export/
|-- innovus_paths.csv
`-- innovus_points.csv
```

It obtains values through `get_property`, including:

- Slack, arrival, required time, CPPR, uncertainty and skew.
- Setup/hold values and timing exception.
- Path group and analysis view.
- Launch/capture clocks and periods.
- Launching point, endpoint and every timing-point object.
- Point delay, arrival, transition, slew and cell name when available.

Properties that are unavailable in a particular Innovus version are exported
as empty fields instead of stopping the run.

### 2. Build the dashboard using Python

```bash
python3 analyze_module_connections_v2.py \
    --collection-dir module_connection_export \
    -o module_connection_v2_out
```

Open:

```text
module_connection_v2_out/module_connection_dashboard.html
```

## Dashboard

The revised dashboard contains:

- Independent hierarchy-depth selection.
- Timing-check, path-group and analysis-view filters.
- Violation-only filter.
- `module_connection_dashboard.html`: module connection flow and quick timing review.
- `module_matrix_dashboard.html`: a separate full-width matrix showing `path count / WNS`.
- Select a graph connection or matrix cell to review all paths in an Excel-like table.
- Click a Path link to open `timing_path_detail.html` with header metrics and timing points.
- Quick review includes beginpoint, endpoint, arrival, required, CPPR, skew, slack, view and group.

Clock points before the launching point are excluded from module connectivity.
Only the launching-point-to-endpoint portion of `timing_points` is used to build
the route and matrix.

## Python outputs

```text
module_connection_v2_out/
|-- timing_paths.csv
|-- timing_points.csv
|-- module_boundaries.csv
|-- module_connection_dashboard.html
|-- module_matrix_dashboard.html
`-- timing_path_detail.html
```

- `timing_paths.csv`: normalized path-level properties.
- `timing_points.csv`: normalized point-level data for auditing/debugging.
- `module_boundaries.csv`: full-depth module connection aggregation.
- `module_connection_dashboard.html`: filtered connection flow and selected-cluster review.
- `module_matrix_dashboard.html`: independent full-width module matrix and selected-cell review.
- `timing_path_detail.html`: path header and point-by-point detail reached from review tables.

## Formatted-report fallback

The previous text-report parser remains available:

```bash
python3 analyze_module_connections_v2.py \
    setup_timing.rpt hold_timing.rpt \
    -o module_connection_v2_out
```

This fallback supports the tested Innovus format, but the collection CSV route
is recommended because customized `report_timing_format` can change table
columns and break text parsing.

## Hierarchy rule

Timing-point object names are expected in pin form:

```text
cpu_module/cpu_sub_module/cpuAPB/u_decode/Y
```

The final two tokens are treated as leaf instance and pin, producing:

```text
/cpu_module/cpu_sub_module/cpuAPB
```

Change the rule if required:

```bash
python3 analyze_module_connections_v2.py \
    --collection-dir module_connection_export \
    --strip-tail 2 \
    -o module_connection_v2_out
```

## Test with the included collection sample

```bash
python3 analyze_module_connections_v2.py \
    --collection-dir sample/collection_export \
    -o sample/output

python3 -m unittest discover -s tests -v
```

## Notes

- Module names are derived from hierarchical instance names, not RTL reference
  module names.
- Flat point names are placed under `/<TOP>`.
- The Tcl procedure does not delete the output directory. It overwrites only
  `innovus_paths.csv` and `innovus_points.csv`.
- Verify `-max_paths` for your installed Innovus release. If your release uses
  a different option spelling, change only that line in the Tcl exporter.
