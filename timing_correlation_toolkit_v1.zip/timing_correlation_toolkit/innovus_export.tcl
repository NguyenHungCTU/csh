# Innovus timing-report exporter.
# Run after the design and target MMMC analysis view are active.

set corr_script_dir [file dirname [file normalize [info script]]]
source [file join $corr_script_dir timing_corr_common.tcl]

set tool_name innovus
set tool_out_dir [file join $::CORR_OUT_DIR $tool_name]
file mkdir $tool_out_dir
set log_file [file join $tool_out_dir export_status.log]
set safe_view [corr_sanitize $::CORR_VIEW_TAG]

corr_log $log_file "Innovus export started: view=$::CORR_VIEW_TAG paths_per_group=$::CORR_NUM_PATHS"

foreach group_name $::CORR_GROUPS {
    if {[catch {set object_pair [corr_group_collections $group_name]} select_error]} {
        corr_log $log_file "ERROR group=$group_name selector failed: $select_error"
        continue
    }

    set from_objects [lindex $object_pair 0]
    set to_objects   [lindex $object_pair 1]
    set from_count [corr_collection_size $from_objects]
    set to_count   [corr_collection_size $to_objects]

    if {$from_count == 0 || $to_count == 0} {
        corr_log $log_file "SKIP group=$group_name empty selector: from=$from_count to=$to_count"
        continue
    }

    foreach check_type $::CORR_CHECKS {
        if {$check_type eq "setup"} {
            set analysis_option -late
        } else {
            set analysis_option -early
        }

        set report_name "${tool_name}__${safe_view}__${check_type}__${group_name}.rpt"
        set report_file [file join $tool_out_dir $report_name]
        set report_command [list report_timing \
            $analysis_option \
            -max_paths $::CORR_NUM_PATHS \
            -nworst 1 \
            -max_slack $::CORR_MAX_SLACK \
            -from $from_objects \
            -to $to_objects]

        corr_log $log_file "RUN check=$check_type group=$group_name from=$from_count to=$to_count file=$report_file"
        if {[catch {redirect -file $report_file $report_command} report_error]} {
            corr_log $log_file "ERROR check=$check_type group=$group_name: $report_error"
        } else {
            corr_log $log_file "DONE check=$check_type group=$group_name"
        }
    }
}

corr_log $log_file "Innovus export completed"

