# Innovus - PrimeTime Timing Correlation Toolkit

This first version compares both setup and hold paths with a user-selected
number of paths for every canonical path group.

## Why the path groups match

The two tools do not have to use identical internal path-group names.
PrimeTime normally creates clock-based path groups, while Innovus flows may use
basic groups such as `reg2reg` or custom groups. The exporters therefore select
paths using the same startpoint/endpoint classes and assign a common comparison
group:

| Canonical group | From | To |
| --- | --- | --- |
| `REG2REG` | register clock pins | register data pins |
| `IN2REG` | input ports | register data pins |
| `REG2OUT` | register clock pins | output ports |
| `IN2OUT` | input ports | output ports |

The original tool path-group names remain in `path_comparison.csv` as
`innovus_path_group` and `primetime_path_group` for debugging.

This read-only classification is safer than calling `group_path` during the
correlation run because creating or changing path groups can affect a later
Innovus optimization step.

## 1. Configure the run

From csh/tcsh, source the setup file before starting both tools:

```csh
source setup_timing_corr.csh
```

It asks for:

- Number of paths per group and per check. For example, `100` means up to 100
  setup paths and 100 hold paths for each canonical group.
- A canonical view tag. Use the same tag for the corresponding Innovus view and
  PrimeTime scenario even if their real names differ.
- A common output directory.

For already-open tool sessions, set the values directly before sourcing an
exporter:

```tcl
set ::env(TIMING_CORR_NUM_PATHS) 100
set ::env(TIMING_CORR_VIEW) FUNC_SS_MAX
set ::env(TIMING_CORR_OUTDIR) /project/reports/timing_corr_out
```

## 2. Export Innovus reports

Load the design and activate the intended MMMC view first. Then run:

```tcl
source /path/to/timing_correlation_toolkit/innovus_export.tcl
```

Innovus uses `-late` for setup and `-early` for hold.

## 3. Export PrimeTime reports

Load the matching design/scenario first. Then run:

```tcl
source /path/to/timing_correlation_toolkit/pt_export.tcl
```

PrimeTime uses `-delay_type max` for setup and `-delay_type min` for hold.

Both exporters use `-max_paths N` and `-nworst 1`. Therefore `N` is a total
path limit for each canonical group/check, with at most one reported path per
endpoint.

## 4. Compare

Run outside the EDA tools:

```bash
python3 compare_timing.py \
  --input /project/reports/timing_corr_out \
  --output /project/reports/timing_corr_out/comparison
```

Default thresholds are:

- `PASS`: absolute slack delta <= 10 ps
- `WARNING`: 10 ps < absolute slack delta <= 30 ps
- `FAIL`: absolute slack delta > 30 ps

They can be changed:

```bash
python3 compare_timing.py \
  --input /project/reports/timing_corr_out \
  --output /project/reports/timing_corr_out/comparison \
  --warn-ps 20 \
  --fail-ps 50
```

Outputs:

- `summary.csv`: WNS and delta statistics by view/check/group.
- `path_comparison.csv`: matched path details and arrival/required/slack deltas.
- `unmatched_paths.csv`: paths present in only one tool's top-N list.

## Matching behavior

The primary key is:

```text
canonical view + setup/hold + canonical group + startpoint + endpoint
```

If more than one path has the same key, the script sorts those paths by slack
and pairs them in worst-to-best order. A later version can add a full pin-list
signature for topology-level matching.

Two independently generated top-N lists can legitimately contain different
paths near the Nth boundary. These are reported as `MISSING_INNOVUS` or
`MISSING_PRIMETIME`; they are not automatically timing failures.

## Correlation prerequisites

Before treating a delta as a tool-correlation issue, align netlist, SPEF,
libraries, SDC/exceptions, PVT and RC corner, propagated clocks, SI, OCV/AOCV/
POCV, CPPR/CRPR, and GBA/PBA settings.

## Current scope

This version covers the four basic data-path groups. Register-to-clock-gate and
other special checks are intentionally not folded into `REG2REG`; they can be
added with tool-specific endpoint selectors after confirming the clock-gating
cell recognition used by the project libraries.

