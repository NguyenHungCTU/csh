# Common configuration and path selectors for Innovus and PrimeTime timing
# correlation. This file intentionally uses commands shared by the two tools.

proc corr_env_or_default {name default_value} {
    if {[info exists ::env($name)] && [string trim $::env($name)] ne ""} {
        return [string trim $::env($name)]
    }
    return $default_value
}

proc corr_read_positive_integer {} {
    set default_value 100
    if {[info exists ::env(TIMING_CORR_NUM_PATHS)]} {
        set value [string trim $::env(TIMING_CORR_NUM_PATHS)]
    } else {
        puts -nonewline "Number of paths per group/check \[$default_value\]: "
        flush stdout
        if {[gets stdin value] < 0 || [string trim $value] eq ""} {
            set value $default_value
        }
    }

    if {![string is integer -strict $value] || $value <= 0} {
        error "TIMING_CORR_NUM_PATHS must be a positive integer; got '$value'"
    }
    return $value
}

proc corr_sanitize {value} {
    regsub -all {[^A-Za-z0-9_.-]} $value {_} value
    return $value
}

proc corr_collection_size {objects} {
    if {[catch {sizeof_collection $objects} count]} {
        return -1
    }
    return $count
}

proc corr_group_collections {group_name} {
    # The canonical group is assigned by the query itself. It is independent
    # of the tool's internal path-group name.
    switch -- $group_name {
        REG2REG {
            set from_objects [corr_register_clock_pins]
            set to_objects   [corr_register_data_pins]
        }
        IN2REG {
            set from_objects [all_inputs]
            set to_objects   [corr_register_data_pins]
        }
        REG2OUT {
            set from_objects [corr_register_clock_pins]
            set to_objects   [all_outputs]
        }
        IN2OUT {
            set from_objects [all_inputs]
            set to_objects   [all_outputs]
        }
        default {
            error "Unsupported canonical group '$group_name'"
        }
    }
    return [list $from_objects $to_objects]
}

proc corr_register_clock_pins {} {
    if {[catch {all_registers -clock_pins} objects]} {
        # Compatibility fallback for a legacy shell whose all_registers does
        # not expose the PrimeTime-style pin selector.
        return [all_registers]
    }
    return $objects
}

proc corr_register_data_pins {} {
    if {[catch {all_registers -data_pins} objects]} {
        return [all_registers]
    }
    return $objects
}

proc corr_log {log_file message} {
    set timestamp [clock format [clock seconds] -format "%Y-%m-%d %H:%M:%S"]
    set line "\[$timestamp\] $message"
    puts $line
    set handle [open $log_file a]
    puts $handle $line
    close $handle
}

set ::CORR_NUM_PATHS [corr_read_positive_integer]
set ::CORR_VIEW_TAG [corr_env_or_default TIMING_CORR_VIEW ACTIVE_VIEW]
set ::CORR_OUT_DIR [corr_env_or_default TIMING_CORR_OUTDIR [file join [pwd] timing_corr_out]]
set ::CORR_MAX_SLACK [corr_env_or_default TIMING_CORR_MAX_SLACK 1000000.0]

if {[info exists ::env(TIMING_CORR_GROUPS)] && [string trim $::env(TIMING_CORR_GROUPS)] ne ""} {
    set ::CORR_GROUPS [split $::env(TIMING_CORR_GROUPS) ,]
} else {
    set ::CORR_GROUPS {REG2REG IN2REG REG2OUT IN2OUT}
}

set ::CORR_CHECKS {setup hold}
