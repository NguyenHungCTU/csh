#!/bin/csh -f

# Source this file before launching Innovus and PrimeTime so both tools inherit
# exactly the same path limit, canonical view tag, and output directory.

printf "Number of paths per group/check [100]: "
set corr_num_paths = "$<"
if ("$corr_num_paths" == "") set corr_num_paths = 100

printf "Canonical view tag used by both tools [ACTIVE_VIEW]: "
set corr_view_tag = "$<"
if ("$corr_view_tag" == "") set corr_view_tag = ACTIVE_VIEW

set corr_default_out = "$cwd/timing_corr_out"
printf "Output directory [$corr_default_out]: "
set corr_out_dir = "$<"
if ("$corr_out_dir" == "") set corr_out_dir = "$corr_default_out"

setenv TIMING_CORR_NUM_PATHS "$corr_num_paths"
setenv TIMING_CORR_VIEW "$corr_view_tag"
setenv TIMING_CORR_OUTDIR "$corr_out_dir"
setenv TIMING_CORR_GROUPS "REG2REG,IN2REG,REG2OUT,IN2OUT"

echo ""
echo "Timing correlation environment configured:"
echo "  paths/group/check : $TIMING_CORR_NUM_PATHS"
echo "  canonical view    : $TIMING_CORR_VIEW"
echo "  output directory  : $TIMING_CORR_OUTDIR"
echo "  canonical groups  : $TIMING_CORR_GROUPS"

