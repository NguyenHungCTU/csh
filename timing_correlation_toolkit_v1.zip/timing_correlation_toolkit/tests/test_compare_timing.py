import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).resolve().parents[1] / "compare_timing.py"
SPEC = importlib.util.spec_from_file_location("compare_timing", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


PRIMETIME_REPORT = """
Startpoint: top/u_launch/Q (rising edge-triggered flip-flop clocked by CLK_A)
Endpoint: top/u_capture/D (rising edge-triggered flip-flop clocked by CLK_B)
Path Group: CLK_B
Path Type: max
  data arrival time                           1.250
  data required time                          1.200
  data required time                          1.200
  data arrival time                          -1.250
  slack (VIOLATED)                           -0.050
"""


INNOVUS_REPORT = """
Path 1: VIOLATED Setup Check with Pin top/u_capture/CK
Endpoint: top/u_capture/D (v) checked with leading edge of 'CLK_B'
Beginpoint: top/u_launch/Q (v) triggered by leading edge of 'CLK_A'
Path Groups: {reg2reg}
= Required Time 1.210
- Arrival Time 1.255
= Slack Time -0.045
"""


class ParserTest(unittest.TestCase):
    def test_parse_and_compare(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            pt_dir = root / "primetime"
            inv_dir = root / "innovus"
            pt_dir.mkdir()
            inv_dir.mkdir()
            (pt_dir / "primetime__FUNC_SS__setup__REG2REG.rpt").write_text(
                PRIMETIME_REPORT, encoding="utf-8"
            )
            (inv_dir / "innovus__FUNC_SS__setup__REG2REG.rpt").write_text(
                INNOVUS_REPORT, encoding="utf-8"
            )

            paths = MODULE.load_reports(root)
            self.assertEqual(len(paths), 2)
            pairs = MODULE.pair_paths(paths)
            rows = MODULE.comparison_rows(pairs, 1000.0, 10.0, 30.0)

            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["status"], "PASS")
            self.assertEqual(rows[0]["delta_slack_ps"], "5.000")
            self.assertEqual(rows[0]["innovus_path_group"], "reg2reg")
            self.assertEqual(rows[0]["primetime_path_group"], "CLK_B")
            self.assertEqual(rows[0]["innovus_launch_clock"], "CLK_A")
            self.assertEqual(rows[0]["primetime_capture_clock"], "CLK_B")
            self.assertEqual(rows[0]["primetime_arrival"], "1.250000")


if __name__ == "__main__":
    unittest.main()
