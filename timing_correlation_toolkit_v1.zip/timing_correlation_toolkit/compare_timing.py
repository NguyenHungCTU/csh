#!/usr/bin/env python3
"""Compare normalized path-level timing results from Innovus and PrimeTime."""

from __future__ import annotations

import argparse
import csv
import math
import re
import statistics
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?"


@dataclass
class TimingPath:
    tool: str
    source_report: str
    view: str
    check_type: str
    compare_group: str
    report_rank: int
    startpoint: str = ""
    endpoint: str = ""
    tool_path_group: str = ""
    launch_clock: str = ""
    capture_clock: str = ""
    arrival: Optional[float] = None
    required: Optional[float] = None
    slack: Optional[float] = None

    @property
    def base_key(self) -> Tuple[str, str, str, str, str]:
        return (
            self.view,
            self.check_type,
            self.compare_group,
            self.startpoint,
            self.endpoint,
        )


def parse_report_identity(path: Path) -> Tuple[str, str, str, str]:
    parts = path.stem.split("__", 3)
    if len(parts) != 4:
        raise ValueError(
            f"Unexpected report name '{path.name}'. Expected "
            "tool__view__check__group.rpt"
        )
    tool, view, check_type, group = parts
    if tool not in {"innovus", "primetime"}:
        raise ValueError(f"Unknown tool '{tool}' in {path.name}")
    if check_type not in {"setup", "hold"}:
        raise ValueError(f"Unknown check type '{check_type}' in {path.name}")
    return tool, view, check_type, group


def as_float(text: str) -> Optional[float]:
    try:
        value = float(text)
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def final_number(line: str) -> Optional[float]:
    match = re.search(rf"({NUMBER})\s*$", line)
    return as_float(match.group(1)) if match else None


def clock_from_description(line: str) -> str:
    patterns = (
        r"clocked by\s+['\"]?([^'\"\s\)]+)",
        r"(?:checked with|triggered by).*?edge of\s+['\"]([^'\"]+)['\"]",
    )
    for pattern in patterns:
        match = re.search(pattern, line, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return ""


def parse_primetime(path: Path, view: str, check_type: str, group: str) -> List[TimingPath]:
    paths: List[TimingPath] = []
    current: Optional[TimingPath] = None

    def finish() -> None:
        nonlocal current
        if current and current.startpoint and current.endpoint and current.slack is not None:
            paths.append(current)
        current = None

    with path.open("r", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            start_match = re.match(r"\s*Startpoint:\s+(\S+)", line, re.IGNORECASE)
            if start_match:
                finish()
                current = TimingPath(
                    tool="primetime",
                    source_report=str(path),
                    view=view,
                    check_type=check_type,
                    compare_group=group,
                    report_rank=len(paths) + 1,
                    startpoint=start_match.group(1),
                    launch_clock=clock_from_description(line),
                )
                continue
            if current is None:
                continue

            endpoint_match = re.match(r"\s*Endpoint:\s+(\S+)", line, re.IGNORECASE)
            if endpoint_match:
                current.endpoint = endpoint_match.group(1)
                current.capture_clock = clock_from_description(line)
                continue

            group_match = re.match(r"\s*Path Group:\s*(.+?)\s*$", line, re.IGNORECASE)
            if group_match:
                current.tool_path_group = group_match.group(1).strip()
                continue

            if re.match(r"\s*data arrival time\b", line, re.IGNORECASE):
                # PrimeTime repeats arrival in the final slack equation with
                # a subtraction sign. Keep the first, absolute arrival value.
                if current.arrival is None:
                    current.arrival = final_number(line)
                continue
            if re.match(r"\s*data required time\b", line, re.IGNORECASE):
                if current.required is None:
                    current.required = final_number(line)
                continue
            if re.match(r"\s*slack(?:\s|\()", line, re.IGNORECASE):
                current.slack = final_number(line)

    finish()
    return paths


def parse_innovus(path: Path, view: str, check_type: str, group: str) -> List[TimingPath]:
    paths: List[TimingPath] = []
    current: Optional[TimingPath] = None

    def finish() -> None:
        nonlocal current
        if current and current.startpoint and current.endpoint and current.slack is not None:
            paths.append(current)
        current = None

    with path.open("r", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            path_match = re.match(r"\s*Path\s+(\d+)\s*:", line, re.IGNORECASE)
            if path_match:
                finish()
                current = TimingPath(
                    tool="innovus",
                    source_report=str(path),
                    view=view,
                    check_type=check_type,
                    compare_group=group,
                    report_rank=int(path_match.group(1)),
                )
                continue
            if current is None:
                continue

            endpoint_match = re.match(r"\s*Endpoint:\s+(\S+)", line, re.IGNORECASE)
            if endpoint_match:
                current.endpoint = endpoint_match.group(1)
                current.capture_clock = clock_from_description(line)
                continue

            start_match = re.match(r"\s*Beginpoint:\s+(\S+)", line, re.IGNORECASE)
            if start_match:
                current.startpoint = start_match.group(1)
                current.launch_clock = clock_from_description(line)
                continue

            group_match = re.match(r"\s*Path Groups?:\s*(.+?)\s*$", line, re.IGNORECASE)
            if group_match:
                current.tool_path_group = group_match.group(1).strip().strip("{}")
                continue

            if re.match(r"\s*=?\s*Required Time\b", line, re.IGNORECASE):
                current.required = final_number(line)
                continue
            if re.match(r"\s*-?\s*Arrival Time\b", line, re.IGNORECASE):
                current.arrival = final_number(line)
                continue
            if re.match(r"\s*=?\s*Slack Time\b", line, re.IGNORECASE):
                current.slack = final_number(line)

    finish()
    return paths


def load_reports(input_dir: Path) -> List[TimingPath]:
    all_paths: List[TimingPath] = []
    for report_path in sorted(input_dir.glob("*/*.rpt")):
        tool, view, check_type, group = parse_report_identity(report_path)
        if tool == "primetime":
            all_paths.extend(parse_primetime(report_path, view, check_type, group))
        else:
            all_paths.extend(parse_innovus(report_path, view, check_type, group))
    return all_paths


def value_or_blank(value: Optional[float]) -> object:
    return "" if value is None else f"{value:.6f}"


def delta(left: Optional[float], right: Optional[float], scale: float) -> Optional[float]:
    if left is None or right is None:
        return None
    return (left - right) * scale


def classify(abs_delta_ps: Optional[float], warn_ps: float, fail_ps: float) -> str:
    if abs_delta_ps is None:
        return "NO_SLACK_DATA"
    if abs_delta_ps <= warn_ps:
        return "PASS"
    if abs_delta_ps <= fail_ps:
        return "WARNING"
    return "FAIL"


def pair_paths(paths: Sequence[TimingPath]) -> List[Tuple[Optional[TimingPath], Optional[TimingPath]]]:
    by_tool: Dict[str, Dict[Tuple[str, str, str, str, str], List[TimingPath]]] = {
        "innovus": defaultdict(list),
        "primetime": defaultdict(list),
    }
    for path in paths:
        by_tool[path.tool][path.base_key].append(path)

    keys = sorted(set(by_tool["innovus"]) | set(by_tool["primetime"]))
    pairs: List[Tuple[Optional[TimingPath], Optional[TimingPath]]] = []
    for key in keys:
        innovus = sorted(
            by_tool["innovus"].get(key, []),
            key=lambda item: (float("inf") if item.slack is None else item.slack, item.report_rank),
        )
        primetime = sorted(
            by_tool["primetime"].get(key, []),
            key=lambda item: (float("inf") if item.slack is None else item.slack, item.report_rank),
        )
        count = max(len(innovus), len(primetime))
        for index in range(count):
            pairs.append(
                (
                    innovus[index] if index < len(innovus) else None,
                    primetime[index] if index < len(primetime) else None,
                )
            )
    return pairs


COMPARISON_FIELDS = [
    "view",
    "check_type",
    "compare_group",
    "startpoint",
    "endpoint",
    "pair_rank",
    "innovus_path_group",
    "primetime_path_group",
    "innovus_launch_clock",
    "primetime_launch_clock",
    "innovus_capture_clock",
    "primetime_capture_clock",
    "innovus_arrival",
    "primetime_arrival",
    "delta_arrival_ps",
    "innovus_required",
    "primetime_required",
    "delta_required_ps",
    "innovus_slack",
    "primetime_slack",
    "delta_slack_ps",
    "abs_delta_slack_ps",
    "status",
]


def comparison_rows(
    pairs: Sequence[Tuple[Optional[TimingPath], Optional[TimingPath]]],
    scale: float,
    warn_ps: float,
    fail_ps: float,
) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    key_ranks: Dict[Tuple[str, str, str, str, str], int] = defaultdict(int)
    for innovus, primetime in pairs:
        exemplar = innovus or primetime
        assert exemplar is not None
        key_ranks[exemplar.base_key] += 1
        pair_rank = key_ranks[exemplar.base_key]

        if innovus is None:
            status = "MISSING_INNOVUS"
        elif primetime is None:
            status = "MISSING_PRIMETIME"
        else:
            slack_delta = delta(innovus.slack, primetime.slack, scale)
            status = classify(None if slack_delta is None else abs(slack_delta), warn_ps, fail_ps)

        arrival_delta = delta(
            None if innovus is None else innovus.arrival,
            None if primetime is None else primetime.arrival,
            scale,
        )
        required_delta = delta(
            None if innovus is None else innovus.required,
            None if primetime is None else primetime.required,
            scale,
        )
        slack_delta = delta(
            None if innovus is None else innovus.slack,
            None if primetime is None else primetime.slack,
            scale,
        )

        rows.append(
            {
                "view": exemplar.view,
                "check_type": exemplar.check_type,
                "compare_group": exemplar.compare_group,
                "startpoint": exemplar.startpoint,
                "endpoint": exemplar.endpoint,
                "pair_rank": pair_rank,
                "innovus_path_group": "" if innovus is None else innovus.tool_path_group,
                "primetime_path_group": "" if primetime is None else primetime.tool_path_group,
                "innovus_launch_clock": "" if innovus is None else innovus.launch_clock,
                "primetime_launch_clock": "" if primetime is None else primetime.launch_clock,
                "innovus_capture_clock": "" if innovus is None else innovus.capture_clock,
                "primetime_capture_clock": "" if primetime is None else primetime.capture_clock,
                "innovus_arrival": value_or_blank(None if innovus is None else innovus.arrival),
                "primetime_arrival": value_or_blank(None if primetime is None else primetime.arrival),
                "delta_arrival_ps": "" if arrival_delta is None else f"{arrival_delta:.3f}",
                "innovus_required": value_or_blank(None if innovus is None else innovus.required),
                "primetime_required": value_or_blank(None if primetime is None else primetime.required),
                "delta_required_ps": "" if required_delta is None else f"{required_delta:.3f}",
                "innovus_slack": value_or_blank(None if innovus is None else innovus.slack),
                "primetime_slack": value_or_blank(None if primetime is None else primetime.slack),
                "delta_slack_ps": "" if slack_delta is None else f"{slack_delta:.3f}",
                "abs_delta_slack_ps": "" if slack_delta is None else f"{abs(slack_delta):.3f}",
                "status": status,
            }
        )
    return rows


def write_csv(path: Path, fieldnames: Sequence[str], rows: Iterable[Dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


SUMMARY_FIELDS = [
    "view",
    "check_type",
    "compare_group",
    "innovus_paths",
    "primetime_paths",
    "matched_paths",
    "missing_innovus",
    "missing_primetime",
    "pass",
    "warning",
    "fail",
    "innovus_wns",
    "primetime_wns",
    "delta_wns_ps",
    "mean_abs_delta_slack_ps",
    "max_abs_delta_slack_ps",
]


def summarize(rows: Sequence[Dict[str, object]], scale: float) -> List[Dict[str, object]]:
    grouped: Dict[Tuple[str, str, str], List[Dict[str, object]]] = defaultdict(list)
    for row in rows:
        grouped[(str(row["view"]), str(row["check_type"]), str(row["compare_group"]))].append(row)

    summaries: List[Dict[str, object]] = []
    for key in sorted(grouped):
        group_rows = grouped[key]
        innovus_slacks = [float(row["innovus_slack"]) for row in group_rows if row["innovus_slack"] != ""]
        primetime_slacks = [float(row["primetime_slack"]) for row in group_rows if row["primetime_slack"] != ""]
        abs_deltas = [float(row["abs_delta_slack_ps"]) for row in group_rows if row["abs_delta_slack_ps"] != ""]
        statuses = [str(row["status"]) for row in group_rows]
        innovus_wns = min(innovus_slacks) if innovus_slacks else None
        primetime_wns = min(primetime_slacks) if primetime_slacks else None
        wns_delta = None
        if innovus_wns is not None and primetime_wns is not None:
            wns_delta = (innovus_wns - primetime_wns) * scale

        summaries.append(
            {
                "view": key[0],
                "check_type": key[1],
                "compare_group": key[2],
                "innovus_paths": len(innovus_slacks),
                "primetime_paths": len(primetime_slacks),
                "matched_paths": sum(status not in {"MISSING_INNOVUS", "MISSING_PRIMETIME"} for status in statuses),
                "missing_innovus": statuses.count("MISSING_INNOVUS"),
                "missing_primetime": statuses.count("MISSING_PRIMETIME"),
                "pass": statuses.count("PASS"),
                "warning": statuses.count("WARNING"),
                "fail": statuses.count("FAIL"),
                "innovus_wns": "" if innovus_wns is None else f"{innovus_wns:.6f}",
                "primetime_wns": "" if primetime_wns is None else f"{primetime_wns:.6f}",
                "delta_wns_ps": "" if wns_delta is None else f"{wns_delta:.3f}",
                "mean_abs_delta_slack_ps": "" if not abs_deltas else f"{statistics.fmean(abs_deltas):.3f}",
                "max_abs_delta_slack_ps": "" if not abs_deltas else f"{max(abs_deltas):.3f}",
            }
        )
    return summaries


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="Root containing innovus/ and primetime/ reports")
    parser.add_argument("--output", type=Path, required=True, help="Directory for comparison CSV files")
    parser.add_argument("--input-unit", choices=("ns", "ps"), default="ns")
    parser.add_argument("--warn-ps", type=float, default=10.0)
    parser.add_argument("--fail-ps", type=float, default=30.0)
    args = parser.parse_args()

    if args.warn_ps < 0 or args.fail_ps < args.warn_ps:
        parser.error("Require 0 <= --warn-ps <= --fail-ps")

    scale = 1000.0 if args.input_unit == "ns" else 1.0
    paths = load_reports(args.input)
    if not paths:
        raise SystemExit(f"No timing paths parsed below {args.input}")

    args.output.mkdir(parents=True, exist_ok=True)
    pairs = pair_paths(paths)
    rows = comparison_rows(pairs, scale, args.warn_ps, args.fail_ps)
    summaries = summarize(rows, scale)

    comparison_file = args.output / "path_comparison.csv"
    summary_file = args.output / "summary.csv"
    unmatched_file = args.output / "unmatched_paths.csv"
    write_csv(comparison_file, COMPARISON_FIELDS, rows)
    write_csv(summary_file, SUMMARY_FIELDS, summaries)
    write_csv(
        unmatched_file,
        COMPARISON_FIELDS,
        (row for row in rows if str(row["status"]).startswith("MISSING_")),
    )

    print(f"Parsed timing paths : {len(paths)}")
    print(f"Compared rows       : {len(rows)}")
    print(f"Summary             : {summary_file}")
    print(f"Path comparison     : {comparison_file}")
    print(f"Unmatched paths     : {unmatched_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
