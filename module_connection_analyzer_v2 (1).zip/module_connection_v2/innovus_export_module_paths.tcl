# Innovus collection-based timing exporter for Module Connection Analyzer V2.
#
# This exporter does not parse the formatted report_timing text.  It reads
# timing-path and timing-point properties directly from Innovus and writes two
# stable CSV files consumed by analyze_module_connections_v2.py.

proc mc_csv_escape {value} {
    set text "$value"
    regsub -all {"} $text {""} text
    return "\"${text}\""
}

proc mc_safe_property {object property {default_value ""}} {
    if {$object eq ""} {
        return $default_value
    }
    if {[catch {get_property $object $property} value]} {
        return $default_value
    }
    if {$value eq "" || $value eq "NA"} {
        return $default_value
    }
    return $value
}

proc mc_safe_object_name {object {default_value ""}} {
    if {$object eq ""} {
        return $default_value
    }
    if {[catch {get_object_name $object} value]} {
        return $default_value
    }
    if {$value eq ""} {
        return $default_value
    }
    return $value
}

proc mc_write_csv_row {channel values} {
    set escaped {}
    foreach value $values {
        lappend escaped [mc_csv_escape $value]
    }
    puts $channel [join $escaped ","]
}

proc mc_clock_info {path property_name} {
    set clock_obj [mc_safe_property $path $property_name ""]
    if {$clock_obj eq ""} {
        return [list "NA" ""]
    }
    set clock_name [mc_safe_object_name $clock_obj "NA"]
    set period [mc_safe_property $clock_obj period ""]
    return [list $clock_name $period]
}

proc mc_requested_check {type_check} {
    set normalized [string tolower $type_check]
    switch -- $normalized {
        "setup" - "late" { return "setup" }
        "hold"  - "early" { return "hold" }
        ""                 { return "NA" }
        default            { return $normalized }
    }
}

proc user_module_analyze { {fromPt ""} {toPt ""} {pathGroup ""} {max_path ""} {output_dir "module_connection_export"} {type_check ""} {viol_only 0} } {
    set c_blue   "\x1b\[1;34m"
    set c_green  "\x1b\[1;32m"
    set c_yellow "\x1b\[1;33m"
    set c_red    "\x1b\[1;31m"
    set c_reset  "\x1b\[0m"

    puts "\t${c_blue}MODULE CONNECTION COLLECTION EXPORT${c_reset}"

    if {$output_dir eq ""} {
        set output_dir "module_connection_export"
    }
    if {[file exists $output_dir] && ![file isdirectory $output_dir]} {
        puts "${c_red}Error: $output_dir exists and is not a directory.${c_reset}"
        return
    }
    file mkdir $output_dir

    set paths_file  [file join $output_dir "innovus_paths.csv"]
    set points_file [file join $output_dir "innovus_points.csv"]
    if {[catch {open $paths_file w} path_channel]} {
        puts "${c_red}Error: Cannot open $paths_file for writing.${c_reset}"
        return
    }
    if {[catch {open $points_file w} point_channel]} {
        close $path_channel
        puts "${c_red}Error: Cannot open $points_file for writing.${c_reset}"
        return
    }

    mc_write_csv_row $path_channel [list \
        Path_ID Slack Path_Group Check_Type Begin_Point End_Point Arrival \
        Required_Time CPPR_Adjustment Clock_Uncertainty Setup_Time Hold_Time \
        Recovery_Time Removal_Time \
        Skew Applied_Exception_Type View Launch_Clock Launch_Clock_Period \
        Capture_Clock Capture_Clock_Period Phase_Shift External_Delay \
        Launching_Input_Delay]

    mc_write_csv_row $point_channel [list \
        Path_ID Point_Index Object_Name Object_Type Cell_Name Transition_Type \
        Delay Arrival Slew Is_Launch_Point Is_End_Point]

    set cmd_opts [list -collection -path_type full_clock -nworst 1]
    if {$fromPt ne ""}    { lappend cmd_opts -from $fromPt }
    if {$toPt ne ""}      { lappend cmd_opts -to $toPt }
    if {$pathGroup ne ""} { lappend cmd_opts -path_group $pathGroup }
    if {$max_path ne ""}  { lappend cmd_opts -max_paths $max_path }

    set normalized_check [string tolower $type_check]
    if {$normalized_check eq "setup" || $normalized_check eq "late"} {
        lappend cmd_opts -late
    } elseif {$normalized_check eq "hold" || $normalized_check eq "early"} {
        lappend cmd_opts -early
    } elseif {$normalized_check ne ""} {
        puts "${c_yellow}Warning: Unknown type_check '$type_check'; no early/late option added.${c_reset}"
    }

    if {[catch {eval report_timing $cmd_opts} path_collection]} {
        set first_error $path_collection
        set max_option_index [lsearch -exact $cmd_opts -max_paths]
        if {$max_option_index >= 0} {
            set fallback_opts $cmd_opts
            lset fallback_opts $max_option_index -max_path
            puts "${c_yellow}Warning: -max_paths failed; retrying with -max_path.${c_reset}"
            if {[catch {eval report_timing $fallback_opts} path_collection]} {
                close $path_channel
                close $point_channel
                puts "${c_red}Error: report_timing collection failed with both max-path option spellings.${c_reset}"
                puts "First attempt: $first_error"
                puts "Fallback attempt: $path_collection"
                return
            }
        } else {
            close $path_channel
            close $point_channel
            puts "${c_red}Error: report_timing collection failed.${c_reset}"
            puts $path_collection
            return
        }
    }

    set path_index 0
    set exported_count 0
    set skipped_count 0

    foreach_in_collection path $path_collection {
        incr path_index
        set slack [mc_safe_property $path slack ""]
        if {$slack eq ""} {
            incr skipped_count
            continue
        }
        if {$viol_only && $slack >= 0} {
            incr skipped_count
            continue
        }

        set points [mc_safe_property $path timing_points ""]
        set point_count 0
        if {$points ne ""} {
            set point_count [sizeof_collection $points]
        }

        set launch_obj [mc_safe_property $path launching_point ""]
        set begin_name [mc_safe_object_name $launch_obj "NA"]

        set end_obj [mc_safe_property $path capturing_point ""]
        if {$end_obj eq ""} {
            set end_obj [mc_safe_property $path endpoint ""]
        }
        set end_name [mc_safe_object_name $end_obj "NA"]
        if {$end_name eq "NA" && $point_count > 0} {
            set last_point [index_collection $points [expr {$point_count - 1}]]
            set end_name [mc_safe_object_name [mc_safe_property $last_point object ""] "NA"]
        }

        set group_obj [mc_safe_property $path path_group ""]
        set group_name [mc_safe_object_name $group_obj "NA"]
        set setup_value [mc_safe_property $path setup ""]
        set hold_value [mc_safe_property $path hold ""]
        set recovery_value [mc_safe_property $path recovery ""]
        set removal_value [mc_safe_property $path removal ""]
        set check_type [mc_safe_property $path check_type ""]
        if {$check_type eq ""} {
            if {$recovery_value ne ""} {
                set check_type "recovery"
            } elseif {$removal_value ne ""} {
                set check_type "removal"
            } elseif {$setup_value ne ""} {
                set check_type "setup"
            } elseif {$hold_value ne ""} {
                set check_type "hold"
            } else {
                set check_type [mc_requested_check $type_check]
            }
        }

        set launch_info [mc_clock_info $path launching_clock]
        set capture_info [mc_clock_info $path capturing_clock]

        mc_write_csv_row $path_channel [list \
            $path_index \
            $slack \
            $group_name \
            $check_type \
            $begin_name \
            $end_name \
            [mc_safe_property $path arrival ""] \
            [mc_safe_property $path required_time ""] \
            [mc_safe_property $path cppr_adjustment ""] \
            [mc_safe_property $path clock_uncertainty ""] \
            $setup_value \
            $hold_value \
            $recovery_value \
            $removal_value \
            [mc_safe_property $path skew ""] \
            [mc_safe_property $path applied_exception_type ""] \
            [mc_safe_property $path view_name "NA"] \
            [lindex $launch_info 0] \
            [lindex $launch_info 1] \
            [lindex $capture_info 0] \
            [lindex $capture_info 1] \
            [mc_safe_property $path phase_shift ""] \
            [mc_safe_property $path external_delay ""] \
            [mc_safe_property $path launching_input_delay ""]]

        set point_index 0
        if {$points ne ""} {
            foreach_in_collection point $points {
                set point_obj [mc_safe_property $point object ""]
                set point_name [mc_safe_object_name $point_obj "NA"]
                set is_launch [expr {$begin_name ne "NA" && $point_name eq $begin_name}]
                set is_end [expr {$end_name ne "NA" && $point_name eq $end_name}]

                set object_type [mc_safe_property $point_obj object_type ""]
                set cell_name [mc_safe_property $point cell_name ""]
                if {$cell_name eq ""} {
                    set cell_obj [mc_safe_property $point_obj cell ""]
                    set cell_name [mc_safe_property $cell_obj ref_name ""]
                }

                mc_write_csv_row $point_channel [list \
                    $path_index \
                    $point_index \
                    $point_name \
                    $object_type \
                    $cell_name \
                    [mc_safe_property $point transition_type ""] \
                    [mc_safe_property $point delay ""] \
                    [mc_safe_property $point arrival ""] \
                    [mc_safe_property $point slew ""] \
                    $is_launch \
                    $is_end]
                incr point_index
            }
        }
        incr exported_count
    }

    close $path_channel
    close $point_channel

    puts "${c_green}Export completed.${c_reset}"
    puts "  Selected paths : $path_index"
    puts "  Exported paths : $exported_count"
    puts "  Skipped paths  : $skipped_count"
    puts "  Path CSV       : $paths_file"
    puts "  Point CSV      : $points_file"
    puts ""
    puts "Run Python:"
    puts "  python3 analyze_module_connections_v2.py --collection-dir $output_dir -o module_connection_v2_out"
}

puts "\tLoaded: user_module_analyze from innovus_export_module_paths.tcl"
