#!/bin/csh -f

set script_dir = `dirname $0`
set collection_dir = "$script_dir/sample/collection_export"
set output_dir = "$script_dir/sample/output"

python3 "$script_dir/analyze_module_connections_v2.py" \
    --collection-dir "$collection_dir" \
    -o "$output_dir" \
    --title "Innovus Module Connection Analysis V2 - Collection Sample"

if ( $status != 0 ) then
    echo "V2 analysis failed"
    exit 1
endif

echo "Open: $output_dir/module_connection_dashboard.html"
