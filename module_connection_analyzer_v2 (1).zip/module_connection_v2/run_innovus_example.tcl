source innovus_export_module_paths.tcl

# Arguments:
# from, to, path_group, max_paths, output_dir, type_check, violations_only
user_module_analyze "" "" "" 1000 module_connection_export late 1
