#!/usr/bin/env python
"""Analyze hierarchical module behavior from Innovus timing-path collections.

The recommended input is the canonical CSV pair exported inside Innovus with
innovus_export_module_paths.tcl.  A formatted-report parser remains available
as a fallback.  Compatible with Python 2.7 and Python 3.x.
"""

from __future__ import print_function

import argparse
import csv
import glob
import io
import json
import math
import os
import re
import sys
from collections import defaultdict


PY2 = sys.version_info[0] == 2
try:
    TEXT_TYPE = unicode
except NameError:
    TEXT_TYPE = str

NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?"
VALID_POLICIES = ("strict", "group_impl", "inherit")


class TimingPoint(object):
    def __init__(self, section, point_index):
        self.section = section
        self.segment = section
        self.point_index = point_index
        self.instance = ""
        self.object_name = ""
        self.arc = ""
        self.cell = ""
        self.delay_mean = None
        self.delay_sigma = None
        self.delay = None
        self.derate = None
        self.slew = None
        self.fanout = None
        self.load = None
        self.arrival_mean = None
        self.arrival_sigma = None
        self.arrival = None
        self.x = None
        self.y = None
        self.delay_kind = "pin"
        self.is_launch_point = False
        self.is_end_point = False


class TimingPath(object):
    def __init__(self, report_file, rank, header):
        self.path_id = 0
        self.report_file = report_file
        self.rank = rank
        self.header = header.strip()
        self.beginpoint = ""
        self.endpoint = ""
        self.path_group = ""
        self.analysis_view = ""
        self.common_point = ""
        self.check_type = parse_check_type(header)
        self.status = parse_status(header)
        self.metrics = {}
        self.points = []
        self.source_tokens = []
        self.destination_tokens = []
        self.launch_clock = ""
        self.launch_clock_period = None
        self.capture_clock = ""
        self.capture_clock_period = None
        self.input_source = "report_text"

    def metric(self, name):
        values = self.metrics.get(name)
        return values[0] if values else None

    def metric_mean(self, name):
        values = self.metrics.get(name)
        return values[1] if values else None

    def metric_sigma(self, name):
        values = self.metrics.get(name)
        return values[2] if values else None

    @property
    def slack(self):
        return self.metric("slack")


def normalize_space(line):
    return line.replace(u"\xa0", u" ").rstrip("\r\n")


def safe_float(value):
    if value is None or value == "-":
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(result) or math.isinf(result):
        return None
    return result


def safe_int(value):
    number = safe_float(value)
    return int(number) if number is not None else None


def parse_check_type(header):
    match = re.search(
        r"^\s*(?:(?:VIOLATED|MET)\s+)?(.+?)\s+Check\b",
        header,
        re.IGNORECASE,
    )
    if not match:
        return "other"
    return re.sub(r"\s+", "_", match.group(1).strip().lower())


def parse_status(header):
    if re.search(r"\bVIOLATED\b", header, re.IGNORECASE):
        return "VIOLATED"
    if re.search(r"\bMET\b", header, re.IGNORECASE):
        return "MET"
    return "UNKNOWN"


def metric_values(line, label):
    """Return nominal, statistical mean and sigma for a named metric."""
    pattern = (
        r"^\s*(?:[=+-]\s*)?"
        + re.escape(label)
        + r"\s*(?:\([^)]*\)\s*)?(?:[:=]\s*)?("
        + NUMBER
        + r")"
    )
    match = re.match(pattern, line, re.IGNORECASE)
    if not match:
        return None
    nominal = safe_float(match.group(1))
    tail = line[match.end() :]
    variation = re.search(
        r"\|\s*(" + NUMBER + r")\s*\|\s*(" + NUMBER + r")",
        tail,
    )
    mean = safe_float(variation.group(1)) if variation else None
    sigma = safe_float(variation.group(2)) if variation else None
    return (nominal, mean, sigma)


def object_from_header(line):
    match = re.match(
        r"\s*(?:Beginpoint|Startpoint|Endpoint):\s+(\S+)",
        line,
        re.IGNORECASE,
    )
    return match.group(1).strip("{}") if match else ""


def object_instance(object_name):
    tokens = [token for token in object_name.strip().strip("{}").strip("/").split("/") if token]
    return "/".join(tokens[:-1]) if len(tokens) > 1 else (tokens[0] if tokens else "")


def hierarchy_tokens(object_name, strip_tail):
    tokens = [token for token in object_name.strip().strip("{}").strip("/").split("/") if token]
    if len(tokens) > strip_tail:
        return tokens[:-strip_tail]
    return ["<TOP>"]


def hierarchy_path(tokens):
    if not tokens or tokens == ["<TOP>"]:
        return "/<TOP>"
    if len(tokens) == 1 and tokens[0].startswith("<"):
        return "/" + tokens[0]
    return "/" + "/".join(tokens)


def normalize_instance(instance):
    return instance.strip().strip("{}").strip("/")


def instance_parent_tokens(instance):
    tokens = [token for token in normalize_instance(instance).split("/") if token]
    return tokens[:-1] if len(tokens) > 1 else []


def implementation_group(point):
    name = normalize_instance(point.instance).split("/")[-1].upper()
    cell = point.cell.upper()
    if name.startswith("FECTS_") or name.startswith("CTS_") or "_CTS_" in name:
        return ["<CTS>"]
    if name.startswith("FE_") or name.startswith("ECO_"):
        return ["<ECO>"]
    if "CLK" in cell or "CK" in cell:
        return ["<CLOCK_IMPL>"]
    return ["<FLAT_IMPL>"]


def point_module_tokens(points, index, policy):
    parent = instance_parent_tokens(points[index].instance)
    if parent:
        return parent
    if policy == "strict":
        return ["<TOP>"]
    if policy == "group_impl":
        return implementation_group(points[index])
    for offset in range(1, len(points) + 1):
        left = index - offset
        right = index + offset
        if left >= 0:
            candidate = instance_parent_tokens(points[left].instance)
            if candidate:
                return candidate
        if right < len(points):
            candidate = instance_parent_tokens(points[right].instance)
            if candidate:
                return candidate
    return implementation_group(points[index])


def is_table_value(value):
    return value == "-" or re.match(r"^(?:" + NUMBER + r")$", value) is not None


def parse_point_line(line, section, point_index):
    """Parse the detailed statistical report table from the numeric tail."""
    clean = normalize_space(line).strip()
    if not clean or clean.startswith("-") or clean.startswith("Instance"):
        return None
    location = re.search(
        r"\(\s*(" + NUMBER + r")\s*,\s*(" + NUMBER + r")\s*\)\s*$",
        clean,
    )
    if not location:
        return None
    x = safe_float(location.group(1))
    y = safe_float(location.group(2))
    tokens = clean[: location.start()].split()
    if len(tokens) < 13:
        return None
    values = tokens[-10:]
    if not all(is_table_value(value) for value in values):
        return None
    prefix = tokens[:-10]
    if len(prefix) < 3:
        return None
    point = TimingPoint(section, point_index)
    point.instance = prefix[0]
    point.cell = prefix[-1]
    point.arc = " ".join(prefix[1:-1])
    point.delay_mean = safe_float(values[0])
    point.delay_sigma = safe_float(values[1])
    point.delay = safe_float(values[2])
    point.derate = safe_float(values[3])
    point.slew = safe_float(values[4])
    point.fanout = safe_int(values[5])
    point.load = safe_float(values[6])
    point.arrival_mean = safe_float(values[7])
    point.arrival_sigma = safe_float(values[8])
    point.arrival = safe_float(values[9])
    point.x = x
    point.y = y
    if "->" in point.arc:
        point.delay_kind = "cell"
    elif point.arc == "-":
        point.delay_kind = "interconnect"
    else:
        point.delay_kind = "pin"
    return point


HEADER_METRICS = [
    ("other_end_arrival", "Other End Arrival Time"),
    ("phase_shift", "Phase Shift"),
    ("cppr_adjustment", "CPPR Adjustment"),
    ("uncertainty", "Uncertainty"),
    ("required", "Required Time"),
    ("arrival", "Arrival Time"),
    ("slack", "Slack Time"),
    ("clock_rise_edge", "Clock Rise Edge"),
    ("source_insertion_delay", "Source Insertion Delay"),
    ("beginpoint_arrival", "Beginpoint Arrival Time"),
]


def classify_segments(path):
    timing_points = [point for point in path.points if point.section == "timing_path"]
    other_points = [point for point in path.points if point.section == "other_end_path"]
    begin_instance = normalize_instance(object_instance(path.beginpoint))
    end_instance = normalize_instance(object_instance(path.endpoint))
    begin_object = normalize_instance(path.beginpoint)
    end_object = normalize_instance(path.endpoint)

    begin_index = None
    for index, point in enumerate(timing_points):
        if point.object_name and normalize_instance(point.object_name) == begin_object:
            begin_index = index
            break
    for index, point in enumerate(timing_points):
        if begin_index is None and normalize_instance(point.instance) == begin_instance and "->" in point.arc:
            begin_index = index
            break
    if begin_index is None:
        for index, point in enumerate(timing_points):
            if normalize_instance(point.instance) == begin_instance:
                begin_index = index
                break

    end_index = None
    for index in range(len(timing_points) - 1, -1, -1):
        if timing_points[index].object_name and normalize_instance(timing_points[index].object_name) == end_object:
            end_index = index
            break
    for index in range(len(timing_points) - 1, -1, -1):
        if end_index is None and normalize_instance(timing_points[index].instance) == end_instance:
            end_index = index
            break

    for index, point in enumerate(timing_points):
        if begin_index is None:
            point.segment = "checked_signal_path"
        elif index < begin_index:
            point.segment = "begin_clock_path"
        elif index == begin_index:
            point.segment = "beginpoint"
        elif end_index is not None and index >= end_index:
            point.segment = "endpoint"
        else:
            point.segment = "checked_signal_path"
    for point in other_points:
        point.segment = "end_clock_path"


def parse_report(report_file, strip_tail):
    parsed = []
    current = None
    section = "header"
    point_index = 0

    def finish(path):
        if path is None or not path.beginpoint or not path.endpoint or path.slack is None:
            return
        path.source_tokens = hierarchy_tokens(path.beginpoint, strip_tail)
        path.destination_tokens = hierarchy_tokens(path.endpoint, strip_tail)
        path.status = "VIOLATED" if path.slack < 0 else "MET"
        classify_segments(path)
        parsed.append(path)

    with io.open(report_file, "r", encoding="utf-8", errors="replace") as stream:
        for raw_line in stream:
            line = normalize_space(raw_line)
            path_match = re.match(r"\s*Path\s+(\d+)\s*:\s*(.*)$", line, re.IGNORECASE)
            if path_match:
                finish(current)
                current = TimingPath(report_file, int(path_match.group(1)), path_match.group(2))
                section = "header"
                point_index = 0
                continue
            if current is None:
                continue
            if re.match(r"\s*Timing Path:\s*$", line, re.IGNORECASE):
                section = "timing_path"
                continue
            if re.match(r"\s*Other End Path:\s*$", line, re.IGNORECASE):
                section = "other_end_path"
                continue
            if re.match(r"\s*(?:Beginpoint|Startpoint):", line, re.IGNORECASE):
                current.beginpoint = object_from_header(line)
                continue
            if re.match(r"\s*Endpoint:", line, re.IGNORECASE):
                current.endpoint = object_from_header(line)
                continue
            group_match = re.match(r"\s*Path Groups?:\s*(.+?)\s*$", line, re.IGNORECASE)
            if group_match:
                current.path_group = group_match.group(1).strip().strip("{}")
                continue
            view_match = re.match(r"\s*Analysis View:\s*(.+?)\s*$", line, re.IGNORECASE)
            if view_match:
                current.analysis_view = view_match.group(1).strip().strip("{}")
                continue
            common_match = re.match(r"\s*Common point:\s+(\S+)", line, re.IGNORECASE)
            if common_match:
                current.common_point = common_match.group(1).strip("{}")
                continue
            if section == "header":
                matched_metric = False
                for key, label in HEADER_METRICS:
                    values = metric_values(line, label)
                    if values:
                        current.metrics[key] = values
                        matched_metric = True
                        break
                if not matched_metric:
                    check_label = current.check_type.replace("_", " ")
                    values = metric_values(line, check_label)
                    if values:
                        current.metrics["check_value"] = values
            if section in ("timing_path", "other_end_path"):
                point = parse_point_line(line, section, point_index + 1)
                if point:
                    point_index += 1
                    point.point_index = point_index
                    current.points.append(point)
    finish(current)
    return parsed


def read_csv_rows(csv_path):
    stream = open(csv_path, "rb") if PY2 else open(csv_path, "r", newline="")
    try:
        reader = csv.DictReader(stream)
        rows = []
        for row in reader:
            clean = {}
            for key, value in row.items():
                if PY2 and isinstance(value, str):
                    try:
                        value = value.decode("utf-8")
                    except UnicodeDecodeError:
                        value = value.decode("latin-1")
                clean[key.strip()] = value.strip() if value is not None else ""
            rows.append(clean)
        return rows
    finally:
        stream.close()


def row_value(row, name, default=""):
    value = row.get(name, default)
    return default if value in (None, "", "NA") else value


def parse_collection_export(export_dir, strip_tail):
    paths_file = os.path.join(export_dir, "innovus_paths.csv")
    points_file = os.path.join(export_dir, "innovus_points.csv")
    if not os.path.isfile(paths_file) or not os.path.isfile(points_file):
        raise SystemExit(
            "Collection export requires innovus_paths.csv and innovus_points.csv in: {0}".format(
                export_dir
            )
        )

    paths = []
    by_export_id = {}
    for row in read_csv_rows(paths_file):
        export_id = row_value(row, "Path_ID")
        if not export_id:
            continue
        check_type = row_value(row, "Check_Type", "other").lower().replace(" ", "_")
        slack = safe_float(row_value(row, "Slack"))
        status = "VIOLATED" if slack is not None and slack < 0 else "MET"
        path = TimingPath(paths_file, int(float(export_id)), "{0} {1} Check".format(status, check_type))
        path.input_source = "innovus_collection"
        path.beginpoint = row_value(row, "Begin_Point")
        path.endpoint = row_value(row, "End_Point")
        path.path_group = row_value(row, "Path_Group")
        path.analysis_view = row_value(row, "View")
        path.launch_clock = row_value(row, "Launch_Clock")
        path.launch_clock_period = safe_float(row_value(row, "Launch_Clock_Period"))
        path.capture_clock = row_value(row, "Capture_Clock")
        path.capture_clock_period = safe_float(row_value(row, "Capture_Clock_Period"))
        path.metrics["slack"] = (slack, None, None)
        metric_columns = [
            ("arrival", "Arrival"),
            ("required", "Required_Time"),
            ("cppr_adjustment", "CPPR_Adjustment"),
            ("uncertainty", "Clock_Uncertainty"),
            ("setup", "Setup_Time"),
            ("hold", "Hold_Time"),
            ("recovery", "Recovery_Time"),
            ("removal", "Removal_Time"),
            ("skew", "Skew"),
            ("phase_shift", "Phase_Shift"),
            ("external_delay", "External_Delay"),
            ("launching_input_delay", "Launching_Input_Delay"),
        ]
        for metric_name, column_name in metric_columns:
            value = safe_float(row_value(row, column_name))
            if value is not None:
                path.metrics[metric_name] = (value, None, None)
        path.metrics["exception_type"] = (row_value(row, "Applied_Exception_Type"), None, None)
        path.status = status
        paths.append(path)
        by_export_id[str(export_id)] = path

    for row in read_csv_rows(points_file):
        export_id = row_value(row, "Path_ID")
        path = by_export_id.get(str(export_id))
        if path is None:
            continue
        point_index = int(float(row_value(row, "Point_Index", len(path.points))))
        point = TimingPoint("timing_path", point_index + 1)
        point.object_name = row_value(row, "Object_Name")
        point.instance = object_instance(point.object_name)
        point.cell = row_value(row, "Cell_Name")
        point.arc = row_value(row, "Transition_Type")
        point.delay = safe_float(row_value(row, "Delay"))
        point.arrival = safe_float(row_value(row, "Arrival"))
        point.slew = safe_float(row_value(row, "Slew"))
        point.is_launch_point = row_value(row, "Is_Launch_Point", "0") in ("1", "true", "TRUE")
        point.is_end_point = row_value(row, "Is_End_Point", "0") in ("1", "true", "TRUE")
        point.delay_kind = "cell" if point.cell else "pin"
        path.points.append(point)

    complete = []
    for path in paths:
        path.points.sort(key=lambda point: point.point_index)
        if not path.beginpoint:
            marked = [point.object_name for point in path.points if point.is_launch_point]
            path.beginpoint = marked[0] if marked else ""
        if not path.endpoint:
            marked = [point.object_name for point in path.points if point.is_end_point]
            path.endpoint = marked[-1] if marked else ""
        if not path.beginpoint or not path.endpoint or path.slack is None:
            continue
        path.source_tokens = hierarchy_tokens(path.beginpoint, strip_tail)
        path.destination_tokens = hierarchy_tokens(path.endpoint, strip_tail)
        classify_segments(path)
        complete.append(path)
    return complete


def expand_inputs(input_patterns):
    files = []
    for pattern in input_patterns:
        matches = sorted(glob.glob(pattern))
        if matches:
            files.extend(matches)
        elif os.path.isfile(pattern):
            files.append(pattern)
    unique = []
    seen = set()
    for path in files:
        absolute = os.path.abspath(path)
        if absolute not in seen:
            seen.add(absolute)
            unique.append(absolute)
    return unique


def checked_signal_points(path):
    return [
        point
        for point in path.points
        if point.segment in ("beginpoint", "checked_signal_path", "endpoint")
    ]


def collapse_route(route):
    collapsed = []
    for tokens in route:
        if not collapsed or tokens != collapsed[-1]:
            collapsed.append(tokens)
    return collapsed


def route_tokens(path, policy):
    points = checked_signal_points(path)
    if not points:
        return collapse_route([path.source_tokens, path.destination_tokens])
    return collapse_route([point_module_tokens(points, index, policy) for index in range(len(points))])


def build_segments(path, policy):
    points = checked_signal_points(path)
    if not points:
        modules = collapse_route([path.source_tokens, path.destination_tokens])
        return [
            {
                "path_id": path.path_id,
                "segment_index": index,
                "module": hierarchy_path(tokens),
                "start_point_index": "",
                "end_point_index": "",
                "point_count": 0,
                "cell_count": 0,
                "total_delay": 0.0,
                "cell_delay": 0.0,
                "interconnect_delay": 0.0,
                "max_slew": None,
                "max_fanout": None,
                "max_load": None,
                "start_x": None,
                "start_y": None,
                "end_x": None,
                "end_y": None,
            }
            for index, tokens in enumerate(modules, 1)
        ]
    modules = [point_module_tokens(points, index, policy) for index in range(len(points))]
    groups = []
    for index, point in enumerate(points):
        module = hierarchy_path(modules[index])
        if not groups or groups[-1][0] != module:
            groups.append([module, []])
        groups[-1][1].append(point)
    rows = []
    for segment_index, item in enumerate(groups, 1):
        module, segment_points = item
        delays = [point.delay for point in segment_points if point.delay is not None]
        cell_delays = [point.delay for point in segment_points if point.delay is not None and point.delay_kind == "cell"]
        net_delays = [point.delay for point in segment_points if point.delay is not None and point.delay_kind == "interconnect"]
        rows.append(
            {
                "path_id": path.path_id,
                "segment_index": segment_index,
                "module": module,
                "start_point_index": segment_points[0].point_index,
                "end_point_index": segment_points[-1].point_index,
                "point_count": len(segment_points),
                "cell_count": sum(point.delay_kind == "cell" for point in segment_points),
                "total_delay": sum(delays),
                "cell_delay": sum(cell_delays),
                "interconnect_delay": sum(net_delays),
                "max_slew": max_or_none(point.slew for point in segment_points),
                "max_fanout": max_or_none(point.fanout for point in segment_points),
                "max_load": max_or_none(point.load for point in segment_points),
                "start_x": segment_points[0].x,
                "start_y": segment_points[0].y,
                "end_x": segment_points[-1].x,
                "end_y": segment_points[-1].y,
            }
        )
    return rows


def max_or_none(values):
    present = [value for value in values if value is not None]
    return max(present) if present else None


def sum_delay(points):
    return sum(point.delay for point in points if point.delay is not None)


def final_arrival(points):
    for point in reversed(points):
        if point.arrival is not None:
            return point.arrival
    return None


def csv_value(value):
    if value is None:
        return ""
    if PY2 and isinstance(value, TEXT_TYPE):
        return value.encode("utf-8")
    return value


def format_number(value):
    return "" if value is None else "{0:.6f}".format(value)


def write_csv(path, fields, rows):
    stream = open(path, "wb") if PY2 else open(path, "w", newline="")
    try:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(dict((key, csv_value(value)) for key, value in row.items()))
    finally:
        stream.close()


PATH_FIELDS = [
    "path_id", "input_source", "report_file", "report_rank", "check_type", "status",
    "path_group", "analysis_view", "common_point", "beginpoint", "endpoint",
    "source_module_full", "destination_module_full", "point_count",
    "begin_clock_point_count", "signal_point_count", "end_clock_point_count",
    "other_end_arrival", "check_value", "phase_shift", "cppr_adjustment",
    "uncertainty", "arrival", "arrival_mean", "arrival_sigma", "required",
    "required_mean", "required_sigma", "slack", "slack_mean", "slack_sigma",
    "setup_time", "hold_time", "recovery_time", "removal_time", "skew", "launch_clock", "launch_clock_period",
    "capture_clock", "capture_clock_period", "external_delay", "launching_input_delay",
]


def path_rows(paths):
    rows = []
    for path in paths:
        segments = defaultdict(int)
        for point in path.points:
            segments[point.segment] += 1
        rows.append({
            "path_id": path.path_id,
            "input_source": path.input_source,
            "report_file": os.path.basename(path.report_file),
            "report_rank": path.rank,
            "check_type": path.check_type,
            "status": path.status,
            "path_group": path.path_group,
            "analysis_view": path.analysis_view,
            "common_point": path.common_point,
            "beginpoint": path.beginpoint,
            "endpoint": path.endpoint,
            "source_module_full": hierarchy_path(path.source_tokens),
            "destination_module_full": hierarchy_path(path.destination_tokens),
            "point_count": len(path.points),
            "begin_clock_point_count": segments["begin_clock_path"],
            "signal_point_count": segments["beginpoint"] + segments["checked_signal_path"] + segments["endpoint"],
            "end_clock_point_count": segments["end_clock_path"],
            "other_end_arrival": format_number(path.metric("other_end_arrival")),
            "check_value": format_number(path.metric("check_value")),
            "phase_shift": format_number(path.metric("phase_shift")),
            "cppr_adjustment": format_number(path.metric("cppr_adjustment")),
            "uncertainty": format_number(path.metric("uncertainty")),
            "arrival": format_number(path.metric("arrival")),
            "arrival_mean": format_number(path.metric_mean("arrival")),
            "arrival_sigma": format_number(path.metric_sigma("arrival")),
            "required": format_number(path.metric("required")),
            "required_mean": format_number(path.metric_mean("required")),
            "required_sigma": format_number(path.metric_sigma("required")),
            "slack": format_number(path.slack),
            "slack_mean": format_number(path.metric_mean("slack")),
            "slack_sigma": format_number(path.metric_sigma("slack")),
            "setup_time": format_number(path.metric("setup")),
            "hold_time": format_number(path.metric("hold")),
            "recovery_time": format_number(path.metric("recovery")),
            "removal_time": format_number(path.metric("removal")),
            "skew": format_number(path.metric("skew")),
            "launch_clock": path.launch_clock,
            "launch_clock_period": format_number(path.launch_clock_period),
            "capture_clock": path.capture_clock,
            "capture_clock_period": format_number(path.capture_clock_period),
            "external_delay": format_number(path.metric("external_delay")),
            "launching_input_delay": format_number(path.metric("launching_input_delay")),
        })
    return rows


POINT_FIELDS = [
    "path_id", "point_index", "section", "segment", "object_name", "instance", "arc", "cell",
    "delay_kind", "delay_mean", "delay_sigma", "delay", "derate", "slew",
    "fanout", "load", "arrival_mean", "arrival_sigma", "arrival", "x", "y",
    "module_strict", "module_group_impl", "module_inherit",
]


def point_rows(paths):
    rows = []
    for path in paths:
        by_section = defaultdict(list)
        for point in path.points:
            by_section[point.section].append(point)
        module_maps = {}
        for section, points in by_section.items():
            module_maps[section] = {}
            for policy in VALID_POLICIES:
                module_maps[section][policy] = [
                    hierarchy_path(point_module_tokens(points, index, policy))
                    for index in range(len(points))
                ]
        section_indexes = defaultdict(int)
        for point in path.points:
            index = section_indexes[point.section]
            section_indexes[point.section] += 1
            rows.append({
                "path_id": path.path_id,
                "point_index": point.point_index,
                "section": point.section,
                "segment": point.segment,
                "object_name": point.object_name,
                "instance": point.instance,
                "arc": point.arc,
                "cell": point.cell,
                "delay_kind": point.delay_kind,
                "delay_mean": format_number(point.delay_mean),
                "delay_sigma": format_number(point.delay_sigma),
                "delay": format_number(point.delay),
                "derate": format_number(point.derate),
                "slew": format_number(point.slew),
                "fanout": "" if point.fanout is None else point.fanout,
                "load": format_number(point.load),
                "arrival_mean": format_number(point.arrival_mean),
                "arrival_sigma": format_number(point.arrival_sigma),
                "arrival": format_number(point.arrival),
                "x": format_number(point.x),
                "y": format_number(point.y),
                "module_strict": module_maps[point.section]["strict"][index],
                "module_group_impl": module_maps[point.section]["group_impl"][index],
                "module_inherit": module_maps[point.section]["inherit"][index],
            })
    return rows


SEGMENT_FIELDS = [
    "path_id", "segment_index", "module", "start_point_index", "end_point_index",
    "point_count", "cell_count", "total_delay", "cell_delay", "interconnect_delay",
    "max_slew", "max_fanout", "max_load", "start_x", "start_y", "end_x", "end_y",
]


def segment_rows(paths, policy):
    rows = []
    for path in paths:
        for row in build_segments(path, policy):
            formatted = dict(row)
            for key in ("total_delay", "cell_delay", "interconnect_delay", "max_slew", "max_load", "start_x", "start_y", "end_x", "end_y"):
                formatted[key] = format_number(row.get(key))
            rows.append(formatted)
    return rows


BOUNDARY_FIELDS = [
    "source_module", "destination_module", "check_type", "path_group",
    "analysis_view", "path_count", "crossing_count", "violation_count",
    "worst_slack", "tns", "average_slack", "average_boundary_step_delay",
]


def boundary_rows(paths, policy):
    groups = {}
    for path in paths:
        segments = build_segments(path, policy)
        if len(segments) == 1:
            pairs = [(segments[0], segments[0])]
        else:
            pairs = list(zip(segments[:-1], segments[1:]))
        for source, destination in pairs:
            key = (source["module"], destination["module"], path.check_type, path.path_group, path.analysis_view)
            if key not in groups:
                groups[key] = {"paths": {}, "crossings": 0, "step_delays": []}
            group = groups[key]
            group["paths"][path.path_id] = path.slack
            group["crossings"] += 1
            group["step_delays"].append(destination["total_delay"])
    rows = []
    for key in sorted(groups):
        group = groups[key]
        slacks = list(group["paths"].values())
        delays = group["step_delays"]
        rows.append({
            "source_module": key[0],
            "destination_module": key[1],
            "check_type": key[2],
            "path_group": key[3],
            "analysis_view": key[4],
            "path_count": len(slacks),
            "crossing_count": group["crossings"],
            "violation_count": sum(value < 0 for value in slacks),
            "worst_slack": format_number(min(slacks)),
            "tns": format_number(sum(value for value in slacks if value < 0)),
            "average_slack": format_number(sum(slacks) / float(len(slacks))),
            "average_boundary_step_delay": format_number(sum(delays) / float(len(delays))) if delays else "",
        })
    return rows


HOTSPOT_FIELDS = [
    "section", "segment", "instance", "cell", "path_count", "occurrence_count",
    "violation_path_count", "total_delay", "max_delay", "max_slew", "max_fanout", "max_load",
]


def hotspot_rows(paths):
    groups = {}
    for path in paths:
        for point in path.points:
            key = (point.section, point.segment, point.instance, point.cell)
            if key not in groups:
                groups[key] = {"paths": set(), "violations": set(), "delays": [], "slews": [], "fanouts": [], "loads": [], "count": 0}
            group = groups[key]
            group["paths"].add(path.path_id)
            if path.slack < 0:
                group["violations"].add(path.path_id)
            group["count"] += 1
            for field, value in (("delays", point.delay), ("slews", point.slew), ("fanouts", point.fanout), ("loads", point.load)):
                if value is not None:
                    group[field].append(value)
    rows = []
    for key, group in groups.items():
        rows.append({
            "section": key[0], "segment": key[1], "instance": key[2], "cell": key[3],
            "path_count": len(group["paths"]), "occurrence_count": group["count"],
            "violation_path_count": len(group["violations"]),
            "total_delay": format_number(sum(group["delays"])),
            "max_delay": format_number(max(group["delays"])) if group["delays"] else "",
            "max_slew": format_number(max(group["slews"])) if group["slews"] else "",
            "max_fanout": max(group["fanouts"]) if group["fanouts"] else "",
            "max_load": format_number(max(group["loads"])) if group["loads"] else "",
        })
    return sorted(rows, key=lambda row: (-row["violation_path_count"], -row["path_count"], row["instance"]))


CLOCK_FIELDS = [
    "path_id", "common_point", "begin_clock_point_count", "end_clock_point_count",
    "begin_clock_delay", "end_clock_delay", "begin_clock_arrival", "end_clock_arrival",
    "calculated_clock_skew", "source_insertion_delay", "other_end_arrival", "cppr_adjustment",
]


def clock_rows(paths):
    rows = []
    for path in paths:
        begin = [point for point in path.points if point.segment == "begin_clock_path"]
        end = [point for point in path.points if point.segment == "end_clock_path"]
        begin_arrival = final_arrival(begin)
        end_arrival = final_arrival(end)
        skew = end_arrival - begin_arrival if begin_arrival is not None and end_arrival is not None else None
        rows.append({
            "path_id": path.path_id,
            "common_point": path.common_point,
            "begin_clock_point_count": len(begin),
            "end_clock_point_count": len(end),
            "begin_clock_delay": format_number(sum_delay(begin)),
            "end_clock_delay": format_number(sum_delay(end)),
            "begin_clock_arrival": format_number(begin_arrival),
            "end_clock_arrival": format_number(end_arrival),
            "calculated_clock_skew": format_number(skew),
            "source_insertion_delay": format_number(path.metric("source_insertion_delay")),
            "other_end_arrival": format_number(path.metric("other_end_arrival")),
            "cppr_adjustment": format_number(path.metric("cppr_adjustment")),
        })
    return rows


def compact_point(point, points, index):
    return {
        "i": point.point_index, "section": point.section, "segment": point.segment,
        "instance": point.instance, "arc": point.arc, "cell": point.cell,
        "kind": point.delay_kind, "delay": point.delay, "slew": point.slew,
        "fanout": point.fanout, "load": point.load, "arrival": point.arrival,
        "x": point.x, "y": point.y,
        "strict": point_module_tokens(points, index, "strict"),
        "group": point_module_tokens(points, index, "group_impl"),
        "inherit": point_module_tokens(points, index, "inherit"),
    }


def dashboard_payload(paths):
    summaries = []
    for path in paths:
        summaries.append({
            "id": path.path_id, "rank": path.rank, "report": os.path.basename(path.report_file),
            "check": path.check_type, "status": path.status,
            "group": path.path_group or "<none>", "view": path.analysis_view or "<none>",
            "begin": path.beginpoint, "end": path.endpoint, "common": path.common_point,
            "slack": path.slack, "arrival": path.metric("arrival"), "required": path.metric("required"),
            "cppr": path.metric("cppr_adjustment"), "uncertainty": path.metric("uncertainty"),
            "otherEnd": path.metric("other_end_arrival"), "checkValue": path.metric("check_value"),
            "phase": path.metric("phase_shift"),
            "setup": path.metric("setup"), "hold": path.metric("hold"),
            "skew": path.metric("skew"),
            "launchClock": path.launch_clock, "launchPeriod": path.launch_clock_period,
            "captureClock": path.capture_clock, "capturePeriod": path.capture_clock_period,
            "route": route_tokens(path, "strict"),
            "pointCount": len(path.points), "source": path.input_source,
        })
    return {"paths": summaries}


def generate_dashboard(template_file, output_file, paths, title):
    with io.open(template_file, "r", encoding="utf-8") as stream:
        template = stream.read()
    content = template.replace("__DASHBOARD_TITLE__", title)
    content = content.replace("__TIMING_DATA__", json.dumps(dashboard_payload(paths), ensure_ascii=True, separators=(",", ":")))
    with io.open(output_file, "w", encoding="utf-8") as stream:
        stream.write(content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reports", nargs="*", help="Formatted Innovus timing reports (fallback input)")
    parser.add_argument(
        "--collection-dir",
        help="Directory containing innovus_paths.csv and innovus_points.csv exported inside Innovus",
    )
    parser.add_argument("-o", "--output", default="module_connection_v2_out")
    parser.add_argument("--strip-tail", type=int, default=2, help="Leaf instance/pin tokens removed from header objects (default: 2)")
    parser.add_argument("--implementation-policy", choices=VALID_POLICIES, default="strict", help=argparse.SUPPRESS)
    parser.add_argument("--dashboard-detail-paths", type=int, default=0, help=argparse.SUPPRESS)
    parser.add_argument("--title", default="Innovus module connection analysis V2")
    args = parser.parse_args()
    if args.strip_tail < 1:
        parser.error("--strip-tail must be at least 1")
    if args.collection_dir and args.reports:
        parser.error("Use either --collection-dir or formatted report files, not both")
    if args.collection_dir:
        collection_dir = os.path.abspath(args.collection_dir)
        paths = parse_collection_export(collection_dir, args.strip_tail)
        input_count = 1
        input_mode = "Innovus collection CSV"
    else:
        report_files = expand_inputs(args.reports)
        if not report_files:
            raise SystemExit("No input found. Use --collection-dir or provide timing report files.")
        paths = []
        for report_file in report_files:
            paths.extend(parse_report(report_file, args.strip_tail))
        input_count = len(report_files)
        input_mode = "Formatted report fallback"
    if not paths:
        raise SystemExit("No complete timing path parsed. Expected Path, Beginpoint, Endpoint and Slack Time lines.")
    for index, path in enumerate(paths, 1):
        path.path_id = index
    output_dir = os.path.abspath(args.output)
    if not os.path.isdir(output_dir):
        os.makedirs(output_dir)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    outputs = {
        "timing_paths.csv": (PATH_FIELDS, path_rows(paths)),
        "timing_points.csv": (POINT_FIELDS, point_rows(paths)),
        "module_boundaries.csv": (BOUNDARY_FIELDS, boundary_rows(paths, "strict")),
    }
    for filename, value in outputs.items():
        write_csv(os.path.join(output_dir, filename), value[0], value[1])
    dashboard_file = os.path.join(output_dir, "module_connection_dashboard.html")
    generate_dashboard(os.path.join(script_dir, "dashboard_template_v2.html"), dashboard_file, paths, args.title)
    print("Python version           : {0}".format(sys.version.split()[0]))
    print("Input mode               : {0}".format(input_mode))
    print("Input sources            : {0}".format(input_count))
    print("Timing paths parsed      : {0}".format(len(paths)))
    print("Detailed timing points   : {0}".format(sum(len(path.points) for path in paths)))
    print("Output directory         : {0}".format(output_dir))
    print("Interactive dashboard    : {0}".format(dashboard_file))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
