#!/bin/csh -f

set script_dir = `dirname $0`
python "$script_dir/analyze_module_connections.py" \
    "$script_dir/sample/sample_innovus_timing.rpt" \
    -o "$script_dir/sample/output" \
    --title "Sample hierarchical module connections"

