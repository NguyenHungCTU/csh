#!/usr/bin/env python
"""Build a hierarchical module-connection dashboard from Innovus timing reports.

Compatible with Python 2.7 and Python 3.x. No third-party package is required.
"""

from __future__ import print_function

import argparse
import csv
import glob
import io
import json
import math
import os
import re
import sys
from collections import defaultdict


PY2 = sys.version_info[0] == 2
try:
    TEXT_TYPE = unicode
except NameError:
    TEXT_TYPE = str

NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?"


class TimingPath(object):
    def __init__(self, report_file, rank, header):
        self.report_file = report_file
        self.rank = rank
        self.header = header.strip()
        self.beginpoint = ""
        self.endpoint = ""
        self.path_group = ""
        self.check_type = parse_check_type(header)
        self.status = parse_status(header)
        self.slack = None
        self.arrival = None
        self.required = None
        self.source_tokens = []
        self.destination_tokens = []


def parse_check_type(header):
    match = re.search(r"\b(Setup|Hold)\b", header, re.IGNORECASE)
    return match.group(1).lower() if match else "other"


def parse_status(header):
    if re.search(r"\bVIOLATED\b", header, re.IGNORECASE):
        return "VIOLATED"
    if re.search(r"\bMET\b", header, re.IGNORECASE):
        return "MET"
    return "UNKNOWN"


def final_number(line):
    match = re.search(r"({0})\s*$".format(NUMBER), line)
    if not match:
        return None
    try:
        value = float(match.group(1))
    except ValueError:
        return None
    if math.isnan(value) or math.isinf(value):
        return None
    return value


def object_from_header(line):
    match = re.match(r"\s*(?:Beginpoint|Startpoint|Endpoint):\s+(\S+)", line, re.IGNORECASE)
    return match.group(1).strip("{}") if match else ""


def hierarchy_tokens(object_name, strip_tail):
    clean_name = object_name.strip().strip("{}").strip("/")
    tokens = [token for token in clean_name.split("/") if token]
    if len(tokens) > strip_tail:
        return tokens[:-strip_tail]
    return ["<TOP>"]


def hierarchy_path(tokens):
    if tokens == ["<TOP>"]:
        return "/<TOP>"
    return "/" + "/".join(tokens)


def parse_report(report_file, strip_tail):
    parsed = []
    current = None

    def finish(path):
        if path is None:
            return
        if not path.beginpoint or not path.endpoint or path.slack is None:
            return
        path.source_tokens = hierarchy_tokens(path.beginpoint, strip_tail)
        path.destination_tokens = hierarchy_tokens(path.endpoint, strip_tail)
        path.status = "VIOLATED" if path.slack < 0 else "MET"
        parsed.append(path)

    with io.open(report_file, "r", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            path_match = re.match(r"\s*Path\s+(\d+)\s*:\s*(.*)$", line, re.IGNORECASE)
            if path_match:
                finish(current)
                current = TimingPath(report_file, int(path_match.group(1)), path_match.group(2))
                continue
            if current is None:
                continue

            if re.match(r"\s*(?:Beginpoint|Startpoint):", line, re.IGNORECASE):
                current.beginpoint = object_from_header(line)
                continue
            if re.match(r"\s*Endpoint:", line, re.IGNORECASE):
                current.endpoint = object_from_header(line)
                continue

            group_match = re.match(r"\s*Path Groups?:\s*(.+?)\s*$", line, re.IGNORECASE)
            if group_match:
                current.path_group = group_match.group(1).strip().strip("{}")
                continue
            if re.match(r"\s*=?\s*Required Time\b", line, re.IGNORECASE):
                current.required = final_number(line)
                continue
            if re.match(r"\s*-?\s*Arrival Time\b", line, re.IGNORECASE):
                current.arrival = final_number(line)
                continue
            if re.match(r"\s*=?\s*Slack Time\b", line, re.IGNORECASE):
                current.slack = final_number(line)

    finish(current)
    return parsed


def expand_inputs(input_patterns):
    files = []
    for pattern in input_patterns:
        matches = sorted(glob.glob(pattern))
        if matches:
            files.extend(matches)
        elif os.path.isfile(pattern):
            files.append(pattern)
    unique = []
    seen = set()
    for path in files:
        absolute = os.path.abspath(path)
        if absolute not in seen:
            seen.add(absolute)
            unique.append(absolute)
    return unique


def csv_value(value):
    if value is None:
        return ""
    if PY2 and isinstance(value, TEXT_TYPE):
        return value.encode("utf-8")
    return value


def write_csv(path, fields, rows):
    stream = open(path, "wb") if PY2 else open(path, "w", newline="")
    try:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(dict((key, csv_value(value)) for key, value in row.items()))
    finally:
        stream.close()


PATH_FIELDS = [
    "path_id",
    "report_file",
    "report_rank",
    "check_type",
    "status",
    "path_group",
    "beginpoint",
    "endpoint",
    "source_module_full",
    "destination_module_full",
    "source_depth",
    "destination_depth",
    "arrival",
    "required",
    "slack",
]


def path_rows(paths):
    rows = []
    for index, path in enumerate(paths, 1):
        rows.append(
            {
                "path_id": index,
                "report_file": os.path.basename(path.report_file),
                "report_rank": path.rank,
                "check_type": path.check_type,
                "status": path.status,
                "path_group": path.path_group,
                "beginpoint": path.beginpoint,
                "endpoint": path.endpoint,
                "source_module_full": hierarchy_path(path.source_tokens),
                "destination_module_full": hierarchy_path(path.destination_tokens),
                "source_depth": len(path.source_tokens),
                "destination_depth": len(path.destination_tokens),
                "arrival": "{0:.6f}".format(path.arrival) if path.arrival is not None else "",
                "required": "{0:.6f}".format(path.required) if path.required is not None else "",
                "slack": "{0:.6f}".format(path.slack),
            }
        )
    return rows


CONNECTION_FIELDS = [
    "source_module",
    "destination_module",
    "check_type",
    "path_group",
    "path_count",
    "violation_count",
    "worst_slack",
    "tns",
    "average_slack",
]


def connection_rows(paths):
    groups = defaultdict(list)
    for path in paths:
        key = (
            hierarchy_path(path.source_tokens),
            hierarchy_path(path.destination_tokens),
            path.check_type,
            path.path_group,
        )
        groups[key].append(path.slack)

    rows = []
    for key in sorted(groups):
        slacks = groups[key]
        rows.append(
            {
                "source_module": key[0],
                "destination_module": key[1],
                "check_type": key[2],
                "path_group": key[3],
                "path_count": len(slacks),
                "violation_count": sum(value < 0 for value in slacks),
                "worst_slack": "{0:.6f}".format(min(slacks)),
                "tns": "{0:.6f}".format(sum(value for value in slacks if value < 0)),
                "average_slack": "{0:.6f}".format(sum(slacks) / float(len(slacks))),
            }
        )
    return rows


def dashboard_data(paths):
    data = []
    for index, path in enumerate(paths, 1):
        data.append(
            {
                "id": index,
                "rank": path.rank,
                "report": os.path.basename(path.report_file),
                "check": path.check_type,
                "status": path.status,
                "group": path.path_group or "<none>",
                "start": path.beginpoint,
                "end": path.endpoint,
                "src": path.source_tokens,
                "dst": path.destination_tokens,
                "slack": path.slack,
            }
        )
    return data


def generate_dashboard(template_file, output_file, paths, title):
    with io.open(template_file, "r", encoding="utf-8") as stream:
        template = stream.read()
    content = template.replace("__DASHBOARD_TITLE__", title)
    content = content.replace("__TIMING_DATA__", json.dumps(dashboard_data(paths), ensure_ascii=True))
    with io.open(output_file, "w", encoding="utf-8") as stream:
        stream.write(content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reports", nargs="+", help="Innovus timing report files or shell globs")
    parser.add_argument("-o", "--output", default="module_connection_out")
    parser.add_argument(
        "--strip-tail",
        type=int,
        default=2,
        help="Hierarchy tokens removed as leaf instance and pin (default: 2)",
    )
    parser.add_argument("--title", default="Innovus module connection analysis")
    args = parser.parse_args()

    if args.strip_tail < 1:
        parser.error("--strip-tail must be at least 1")

    report_files = expand_inputs(args.reports)
    if not report_files:
        raise SystemExit("No input timing report found")

    paths = []
    for report_file in report_files:
        paths.extend(parse_report(report_file, args.strip_tail))
    if not paths:
        raise SystemExit(
            "No complete Innovus timing path parsed. Expected Path, Beginpoint, "
            "Endpoint, and Slack Time lines."
        )

    output_dir = os.path.abspath(args.output)
    if not os.path.isdir(output_dir):
        os.makedirs(output_dir)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    template_file = os.path.join(script_dir, "dashboard_template.html")
    paths_file = os.path.join(output_dir, "timing_paths.csv")
    connections_file = os.path.join(output_dir, "module_connections_full.csv")
    dashboard_file = os.path.join(output_dir, "module_connection_dashboard.html")

    write_csv(paths_file, PATH_FIELDS, path_rows(paths))
    write_csv(connections_file, CONNECTION_FIELDS, connection_rows(paths))
    generate_dashboard(template_file, dashboard_file, paths, args.title)

    max_source_depth = max(len(path.source_tokens) for path in paths)
    max_destination_depth = max(len(path.destination_tokens) for path in paths)
    print("Python version          : {0}".format(sys.version.split()[0]))
    print("Reports parsed          : {0}".format(len(report_files)))
    print("Timing paths parsed     : {0}".format(len(paths)))
    print("Maximum source depth    : {0}".format(max_source_depth))
    print("Maximum destination depth: {0}".format(max_destination_depth))
    print("Timing path CSV         : {0}".format(paths_file))
    print("Connection CSV          : {0}".format(connections_file))
    print("Interactive dashboard   : {0}".format(dashboard_file))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

