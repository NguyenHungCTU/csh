from __future__ import print_function

import os
import sys
import unittest


MODULE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, MODULE_DIR)
import analyze_module_connections as analyzer


class AnalyzerTest(unittest.TestCase):
    def test_sample_report_and_uneven_hierarchy(self):
        report = os.path.join(MODULE_DIR, "sample", "sample_innovus_timing.rpt")
        paths = analyzer.parse_report(report, 2)
        self.assertEqual(len(paths), 12)
        self.assertEqual(
            analyzer.hierarchy_path(paths[0].source_tokens),
            "/cpu_module/cpu_sub_module/cpuAPB",
        )
        self.assertEqual(
            analyzer.hierarchy_path(paths[0].destination_tokens),
            "/sysctrl/module_a/datain/check",
        )
        self.assertEqual(paths[0].check_type, "setup")
        self.assertAlmostEqual(paths[0].slack, -0.145)

    def test_connections_keep_setup_and_hold_separate(self):
        report = os.path.join(MODULE_DIR, "sample", "sample_innovus_timing.rpt")
        rows = analyzer.connection_rows(analyzer.parse_report(report, 2))
        cpu_apb_to_check = [
            row
            for row in rows
            if row["source_module"] == "/cpu_module/cpu_sub_module/cpuAPB"
            and row["destination_module"] == "/sysctrl/module_a/datain/check"
        ]
        self.assertEqual(len(cpu_apb_to_check), 2)
        self.assertEqual(sorted(row["check_type"] for row in cpu_apb_to_check), ["hold", "setup"])


if __name__ == "__main__":
    unittest.main()

