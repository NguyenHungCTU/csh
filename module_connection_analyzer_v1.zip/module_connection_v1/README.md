# Innovus hierarchical module connection analyzer - V1

This tool parses Innovus `report_timing` text reports and builds a visual,
hierarchy-aware view of beginpoint-to-endpoint module connections.

It supports uneven hierarchy depths. Source and destination depths can be
changed independently in the dashboard, so a path such as:

```text
/cpu_module/cpu_sub_module/cpuAPB/reg1/Q
-> /sysctrl/module_a/datain/check/reg2/D
```

can be viewed as any of these aggregations:

```text
/cpu_module -> /sysctrl
/cpu_module/cpu_sub_module -> /sysctrl/module_a
/cpu_module/cpu_sub_module/cpuAPB -> /sysctrl/module_a/datain/check
```

## Requirements

- Python 2.7 or Python 3.x.
- No external Python package.
- A modern browser to open the generated dashboard.

## Generate Innovus reports

The parser requires `Path`, `Beginpoint`, `Endpoint`, `Path Groups`, and
`Slack Time` lines. A comprehensive report can be generated with:

```tcl
set_global report_timing_format {hpin cell slew delay arrival}

redirect -file setup_timing.rpt {
    report_timing -late -net -max_paths 1000
}

redirect -file hold_timing.rpt {
    report_timing -early -net -max_paths 1000
}
```

`-net` is not required by the V1 beginpoint/endpoint parser, but retains useful
path-point information for a future boundary-transition version.

## Run

```bash
python analyze_module_connections.py \
    setup_timing.rpt hold_timing.rpt \
    -o module_connection_out
```

Wildcards are accepted:

```bash
python analyze_module_connections.py "reports/*.rpt" -o module_connection_out
```

## Outputs

```text
module_connection_out/
|-- timing_paths.csv
|-- module_connections_full.csv
`-- module_connection_dashboard.html
```

Open `module_connection_dashboard.html` in a browser. It provides:

- Independent source and destination hierarchy-depth selectors.
- Setup/hold and path-group filters.
- Optional violation-only view.
- Connection flow graph.
- Module-to-module matrix.
- Worst-path details for the selected connection.

## Hierarchy rule

By default, the final two path tokens are treated as leaf instance and pin:

```text
/cpu_module/cpu_sub_module/cpuAPB/reg1/Q
                                     |    |
                                  instance pin
```

The resulting module hierarchy is:

```text
/cpu_module/cpu_sub_module/cpuAPB
```

If the report naming convention differs, change the number of removed tokens:

```bash
python analyze_module_connections.py timing.rpt \
    -o module_connection_out \
    --strip-tail 2
```

## V1 scope

- Analysis is based on hierarchical instance paths shown in the timing report,
  not RTL module reference names.
- V1 aggregates beginpoint module to endpoint module.
- Internal module-boundary transitions along every timing point are reserved
  for a later version.
- Very dense designs display the ten busiest source and destination modules in
  the graph and matrix at the selected hierarchy depths. CSV outputs retain all
  connections.

