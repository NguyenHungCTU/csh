#!/bin/csh -f

set script_dir = `dirname $0`
set report_file = "$script_dir/sample/sample_innovus_full_timing.rpt"
set output_dir = "$script_dir/sample/output"

python3 "$script_dir/analyze_module_connections_v2.py" \
    "$report_file" \
    -o "$output_dir" \
    --implementation-policy group_impl \
    --dashboard-detail-paths 20 \
    --title "Innovus Module Connection Analysis V2 - Sample"

if ( $status != 0 ) then
    echo "V2 analysis failed"
    exit 1
endif

echo "Open: $output_dir/module_connection_dashboard.html"
