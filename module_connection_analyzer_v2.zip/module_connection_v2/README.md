# Innovus Module Connection Analyzer V2

V2 parses the complete Innovus timing-path report, separates clock and checked
signal sections, finds the actual hierarchy boundaries crossed by the checked
signal, and builds a lightweight standalone HTML dashboard.

## Requirements

- Python 2.7 or Python 3.x.
- No third-party Python packages.
- A modern browser for the generated dashboard.

## Expected timing-report structure

```text
Path N: ... Check ...
Endpoint: ...
Beginpoint: ...
Common point: ...
Path Groups: ...
Analysis View: ...
... Required / Arrival / Slack / CPPR ...

Timing Path:
  begin clock path
  beginpoint CK -> Q
  checked signal path
  endpoint D/RB/...

Other End Path:
  end/reference clock path to endpoint clock/check pin
```

The detailed table should contain these fields:

```text
Instance Arc Cell Delay Mean Delay Sigma Delay User Derate Slew Fanout Load
Arrival Mean Arrival Sigma Arrival Time Instance Location
```

The parser accepts statistical header lines such as:

```text
= Slack Time -1.703 (-3.00S) | -1.677 | 0.009
```

The nominal slack is `-1.703`; mean and sigma are exported separately.

## Run

```bash
python3 analyze_module_connections_v2.py \
    reports/setup.rpt reports/hold.rpt \
    -o module_connection_v2_out
```

Shell globs are supported:

```bash
python3 analyze_module_connections_v2.py "reports/*.rpt" \
    -o module_connection_v2_out
```

For older environments:

```bash
python analyze_module_connections_v2.py timing.rpt \
    -o module_connection_v2_out
```

## Main options

```text
--strip-tail 2
    Remove leaf instance and pin tokens from Beginpoint/Endpoint objects.

--implementation-policy group_impl
    Policy used for the exported module_segments.csv and module_boundaries.csv.
    Choices: strict, group_impl, inherit.

--dashboard-detail-paths 200
    Embed detailed timing points only for the worst N paths. All timing points
    remain available in timing_points.csv. This keeps the HTML responsive.
```

Implementation-cell policies:

- `strict`: flat instances become `/<TOP>`.
- `group_impl`: flat CTS/ECO/implementation instances become pseudo modules
  such as `/<CTS>`, `/<ECO>`, and `/<FLAT_IMPL>`.
- `inherit`: a flat implementation instance inherits the nearest hierarchical
  point when possible.

The dashboard lets the user switch among all three policies without rerunning
the parser.

## Outputs

```text
module_connection_v2_out/
|-- timing_paths.csv
|-- timing_points.csv
|-- module_segments.csv
|-- module_boundaries.csv
|-- cell_hotspots.csv
|-- clock_analysis.csv
`-- module_connection_dashboard.html
```

- `timing_paths.csv`: one row per timing path, including statistical header
  values and section point counts.
- `timing_points.csv`: one row per detailed timing point.
- `module_segments.csv`: consecutive checked-signal points collapsed by module.
- `module_boundaries.csv`: aggregated module-to-module boundary crossings.
- `cell_hotspots.csv`: repeated cells/instances and their delay/DRV metrics.
- `clock_analysis.csv`: begin/end clock delay, calculated skew, and CPPR data.
- `module_connection_dashboard.html`: interactive offline visualization.

## Dashboard behavior

- Filters: hierarchy depth, implementation policy, timing check, path group,
  analysis view, and violation-only mode.
- Module connection graph uses only the checked-signal segment.
- Begin clock and Other End clock points stay separate from functional module
  connectivity.
- The selected path page shows header values, path segments, timing points, and
  a physical point-to-point view using reported instance locations.
- Only the 30 busiest boundaries are drawn; CSV data retains all boundaries.
- Only the worst `--dashboard-detail-paths` paths embed point details in HTML.

## Important limitations

- Module names are derived from hierarchical instance paths, not RTL reference
  module names. An instance-to-module mapping file would be required for RTL
  reference names.
- `Instance Location` draws straight lines between cell coordinates. It is not
  routed-wire geometry and cannot replace net RC/SPEF analysis.
- `Arc` rows containing `->` are classified as cell arcs. Rows with `Arc = -`
  are classified as interconnect/pin steps for aggregation.
- Header-only reports still provide endpoint-level routes, but detailed point,
  clock, and physical analysis requires the full report body.

## Test the package

```bash
python3 -m unittest discover -s tests -v
```

## Included sample

```bash
python3 analyze_module_connections_v2.py \
    sample/sample_innovus_full_timing.rpt \
    -o sample/output \
    --dashboard-detail-paths 20
```
